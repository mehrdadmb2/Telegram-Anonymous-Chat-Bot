param(
  [string]$WorkerUrl = "https://anonymous-chat-bot.game-developer-mb.workers.dev",
  [switch]$DropPending
)

$ErrorActionPreference = "Stop"
$WorkerUrl = $WorkerUrl.TrimEnd('/')
$secureSecret = Read-Host "Enter the exact WEBHOOK_SECRET configured in Cloudflare" -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureSecret)
try {
  $secret = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
} finally {
  [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
}
if ([string]::IsNullOrWhiteSpace($secret)) {
  throw "WEBHOOK_SECRET cannot be empty."
}

$drop = if ($DropPending) { "1" } else { "0" }
$uri = "$WorkerUrl/register?drop_pending=$drop"
$result = Invoke-RestMethod -Method Post -Uri $uri -Headers @{ Authorization = "Bearer $secret" }
$result | ConvertTo-Json -Depth 8
$secret = $null
