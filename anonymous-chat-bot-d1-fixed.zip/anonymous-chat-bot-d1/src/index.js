import { Bot } from "grammy/web";

const VERSION = "5.0.0-d1";
const MAX_UPDATE_ATTEMPTS = 7;
const MAX_DELIVERY_ATTEMPTS = 8;
const MAX_NOTIFICATION_ATTEMPTS = 7;
const MAX_PAGE_SIZE = 10;
const DEFAULT_PAGE_SIZE = 8;
const NOW = () => new Date().toISOString();

let cachedRuntime = null;

function escapeHtml(value = "") {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}
function code(value) { return `<code>${escapeHtml(value)}</code>`; }
function quote(value) { return `<blockquote>${escapeHtml(value)}</blockquote>`; }
function shortText(value, max = 240) {
  const text = String(value ?? "").replace(/\s+/g, " ").trim();
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}
function nowMs() { return Date.now(); }
function dateText(value, env = {}) {
  if (!value) return "نامشخص";
  try {
    return new Intl.DateTimeFormat("fa-IR", {
      timeZone: env.TIME_ZONE || "Asia/Tehran",
      calendar: "persian",
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit",
      hour12: false
    }).format(new Date(value));
  } catch {
    return String(value);
  }
}
function botUsername(env) { return String(env.BOT_USERNAME || "NashnasiChatBot").replace(/^@/, ""); }
function linkUrl(env, token) { return `https://t.me/${botUsername(env)}?start=${token}`; }
function profileUrl(id) { return `tg://user?id=${encodeURIComponent(String(id))}`; }
function randomId(length = 20) { return crypto.randomUUID().replaceAll("-", "").slice(0, length); }
function asPage(value) {
  const n = Number.parseInt(String(value || "1"), 10);
  return Number.isFinite(n) ? Math.max(1, Math.min(n, 100000)) : 1;
}
function parseTelegramId(value) {
  const s = String(value || "").trim().replace(/^@/, "");
  return /^\d{1,20}$/.test(s) && Number.isSafeInteger(Number(s)) ? s : null;
}
function messageType(message = {}) {
  const keys = [
    ["text", "text"], ["photo", "photo"], ["video", "video"], ["animation", "animation"],
    ["audio", "audio"], ["document", "document"], ["voice", "voice"], ["video_note", "video_note"],
    ["sticker", "sticker"], ["contact", "contact"], ["location", "location"], ["venue", "venue"],
    ["poll", "poll"], ["dice", "dice"], ["game", "game"], ["invoice", "invoice"],
    ["successful_payment", "payment"], ["story", "story"], ["paid_media", "paid_media"],
    ["live_photo", "live_photo"]
  ];
  for (const [key, value] of keys) if (message[key] !== undefined) return value;
  return "other";
}
function telegramErrorCode(error) {
  return Number(error?.error_code || error?.error?.error_code || error?.status || 0);
}
function telegramErrorText(error) {
  return shortText(error?.description || error?.message || String(error), 500);
}
function isRetryable(error) {
  const codeValue = telegramErrorCode(error);
  return codeValue === 429 || codeValue >= 500 || codeValue === 0;
}
function retryDelay(attempt, error) {
  const retryAfter = Number(error?.parameters?.retry_after || error?.error?.parameters?.retry_after || 0);
  if (retryAfter > 0) return Math.min(retryAfter * 1000, 15 * 60 * 1000);
  return Math.min(2000 * (2 ** Math.max(0, attempt - 1)), 5 * 60 * 1000);
}
function jsonResponse(payload, status = 200) {
  return new Response(JSON.stringify(payload, null, 2), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
  });
}
function safeEqual(a, b) {
  const left = new TextEncoder().encode(String(a || ""));
  const right = new TextEncoder().encode(String(b || ""));
  if (left.length !== right.length) return false;
  let diff = 0;
  for (let i = 0; i < left.length; i++) diff |= left[i] ^ right[i];
  return diff === 0;
}
function requireEnv(env) {
  const missing = [];
  for (const key of ["BOT_TOKEN", "ADMIN_ID", "WEBHOOK_SECRET", "DB"]) {
    if (!env[key]) missing.push(key);
  }
  if (missing.length) throw new Error(`Missing required Worker settings: ${missing.join(", ")}`);
  if (!/^[A-Za-z0-9_-]{1,256}$/.test(String(env.WEBHOOK_SECRET))) {
    throw new Error("WEBHOOK_SECRET must contain only letters, digits, underscores, or hyphens (1-256 chars).");
  }
}

async function run(db, sql, ...values) {
  return db.prepare(sql).bind(...values).run();
}
async function first(db, sql, ...values) {
  return db.prepare(sql).bind(...values).first();
}
async function all(db, sql, ...values) {
  const result = await db.prepare(sql).bind(...values).all();
  return result?.results || [];
}
async function logError(env, location, error, updateId = null) {
  const message = telegramErrorText(error);
  console.error(`[${location}]`, updateId ?? "", message, error?.stack || "");
  try {
    await run(env.DB,
      `INSERT INTO app_errors(location, update_id, error_message, stack, created_at) VALUES(?,?,?,?,?)`,
      String(location), updateId == null ? null : String(updateId), message,
      shortText(error?.stack || "", 3000), NOW());
  } catch (loggingError) {
    console.error("Unable to save app error", loggingError);
  }
}
async function audit(env, actorId, action, targetId = null, messageId = null, details = {}) {
  await run(env.DB,
    `INSERT INTO audit_logs(actor_id, action, target_id, message_id, details_json, created_at) VALUES(?,?,?,?,?,?)`,
    actorId == null ? null : String(actorId), String(action), targetId == null ? null : String(targetId),
    messageId == null ? null : Number(messageId), JSON.stringify(details || {}), NOW());
}
async function enqueueNotification(env, dedupeKey, recipientId, textHtml, replyMarkup = null) {
  await run(env.DB, `INSERT OR IGNORE INTO notifications
    (dedupe_key, recipient_id, text_html, reply_markup_json, status, attempts, next_attempt_at, created_at)
    VALUES(?,?,?,?, 'pending', 0, 0, ?)`, String(dedupeKey), String(recipientId), String(textHtml),
    replyMarkup ? JSON.stringify(replyMarkup) : null, NOW());
}
async function markBlocked(env, userId, reason = "telegram_403") {
  await run(env.DB, `UPDATE users SET bot_blocked_at=COALESCE(bot_blocked_at, ?), updated_at=? WHERE id=?`, NOW(), NOW(), String(userId));
  await audit(env, null, "recipient_unreachable", String(userId), null, { reason });
}
async function upsertUser(env, user) {
  if (!user?.id) return;
  const id = String(user.id);
  const now = NOW();
  await run(env.DB, `INSERT INTO users
    (id, username, first_name, last_name, language_code, is_premium, created_at, last_seen_at, updated_at)
    VALUES(?,?,?,?,?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET
      username=excluded.username, first_name=excluded.first_name, last_name=excluded.last_name,
      language_code=excluded.language_code, is_premium=excluded.is_premium,
      last_seen_at=excluded.last_seen_at, updated_at=excluded.updated_at`,
    id, user.username || null, user.first_name || null, user.last_name || null,
    user.language_code || null, Number(Boolean(user.is_premium)), now, now, now);
}
async function ensureUserStub(env, userId) {
  const now = NOW();
  await run(env.DB, `INSERT OR IGNORE INTO users(id, created_at, last_seen_at, updated_at) VALUES(?,?,?,?)`, String(userId), now, now, now);
}
async function isAdmin(env, userId) {
  const id = String(userId);
  if (id === String(env.ADMIN_ID)) return true;
  return Boolean(await first(env.DB, `SELECT 1 AS ok FROM admins WHERE user_id=?`, id));
}
async function isOwner(env, userId) { return String(userId) === String(env.ADMIN_ID); }
async function listAdminIds(env) {
  const rows = await all(env.DB, `SELECT user_id FROM admins`);
  return [...new Set([String(env.ADMIN_ID), ...rows.map(row => String(row.user_id))])];
}
async function getUser(env, userId) {
  return first(env.DB, `SELECT * FROM users WHERE id=?`, String(userId));
}
async function ensureLink(env, userId) {
  const user = await getUser(env, userId);
  if (!user) await ensureUserStub(env, userId);
  let row = await getUser(env, userId);
  if (row?.link_token) return row.link_token;
  const token = randomId(22);
  await run(env.DB, `UPDATE users SET link_token=COALESCE(link_token, ?), updated_at=? WHERE id=?`, token, NOW(), String(userId));
  row = await getUser(env, userId);
  return row.link_token;
}
async function getConversation(env, conversationId) {
  return first(env.DB, `SELECT * FROM conversations WHERE id=?`, String(conversationId));
}
async function getOrCreateConversation(env, userId, otherId, startedBy = userId) {
  const aId = String(userId), bId = String(otherId);
  if (aId === bId) throw new Error("A conversation cannot target the same user.");
  const [a, b] = [aId, bId].sort();
  let row = await first(env.DB, `SELECT * FROM conversations WHERE user_a=? AND user_b=?`, a, b);
  if (!row) {
    await run(env.DB, `INSERT OR IGNORE INTO conversations
      (id, user_a, user_b, started_by, status, created_at, updated_at)
      VALUES(?,?,?,?, 'active', ?, ?)`, randomId(20), a, b, String(startedBy), NOW(), NOW());
    row = await first(env.DB, `SELECT * FROM conversations WHERE user_a=? AND user_b=?`, a, b);
  }
  if (row?.status !== "active") {
    await run(env.DB, `UPDATE conversations SET status='active', updated_at=? WHERE id=?`, NOW(), row.id);
    row.status = "active";
  }
  return row;
}
async function setActiveConversation(env, userId, conversationId) {
  await run(env.DB, `INSERT INTO user_states(user_id, active_conversation_id, updated_at) VALUES(?,?,?)
    ON CONFLICT(user_id) DO UPDATE SET active_conversation_id=excluded.active_conversation_id, updated_at=excluded.updated_at`,
    String(userId), String(conversationId), NOW());
}
async function activeConversation(env, userId) {
  const state = await first(env.DB, `SELECT active_conversation_id FROM user_states WHERE user_id=?`, String(userId));
  if (!state?.active_conversation_id) return null;
  const conversation = await getConversation(env, state.active_conversation_id);
  if (!conversation || conversation.status !== "active") return null;
  if (conversation.user_a !== String(userId) && conversation.user_b !== String(userId)) return null;
  return conversation;
}
function otherParticipant(conversation, userId) {
  return conversation.user_a === String(userId) ? conversation.user_b : conversation.user_a;
}
async function isBlockedBetween(env, conversationId, blockerId, blockedId) {
  return Boolean(await first(env.DB, `SELECT 1 AS ok FROM conversation_blocks WHERE conversation_id=? AND blocker_id=? AND blocked_id=?`,
    String(conversationId), String(blockerId), String(blockedId)));
}
async function getSetting(env, key, fallback = "") {
  const row = await first(env.DB, `SELECT value FROM settings WHERE key=?`, String(key));
  return row?.value ?? fallback;
}
async function setSetting(env, key, value, actorId) {
  await run(env.DB, `INSERT INTO settings(key,value,updated_at) VALUES(?,?,?)
    ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at`, String(key), String(value), NOW());
  await audit(env, actorId, "setting_changed", key, null, { value: String(value) });
}
async function limited(env, userId) {
  const limit = Math.max(5, Math.min(120, Number(env.RATE_LIMIT_PER_MINUTE || 25)));
  const now = nowMs();
  const row = await first(env.DB, `SELECT window_start, request_count FROM rate_limits WHERE user_id=?`, String(userId));
  if (!row || now - Number(row.window_start) >= 60000) {
    await run(env.DB, `INSERT INTO rate_limits(user_id,window_start,request_count) VALUES(?,?,1)
      ON CONFLICT(user_id) DO UPDATE SET window_start=excluded.window_start, request_count=1`, String(userId), now);
    return true;
  }
  if (Number(row.request_count) >= limit) return false;
  await run(env.DB, `UPDATE rate_limits SET request_count=request_count+1 WHERE user_id=?`, String(userId));
  return true;
}
function userName(user) {
  if (!user) return "نام ثبت‌نشده";
  const full = [user.first_name, user.last_name].filter(Boolean).join(" ").trim();
  return full || (user.username ? `@${user.username}` : "نام ثبت‌نشده");
}
function usernameText(user) { return user?.username ? `@${escapeHtml(user.username)}` : "ندارد"; }
function deliveryStatusFa(status) {
  return ({ pending: "در صف ارسال", processing: "در حال ارسال", sent: "تحویل شد", failed: "ناموفق", blocked: "ربات مسدود است", cancelled: "لغو شد", partial: "تحویل ناقص" })[status] || status || "نامشخص";
}
function typeFa(type) {
  return ({ text: "متن", photo: "عکس", video: "ویدئو", animation: "گیف", audio: "صوت", document: "فایل", voice: "پیام صوتی", video_note: "ویدئو مسیج", sticker: "استیکر", contact: "مخاطب", location: "موقعیت", venue: "مکان", poll: "نظرسنجی", dice: "تاس", game: "بازی", invoice: "فاکتور", payment: "پرداخت", story: "استوری", paid_media: "رسانه پولی", live_photo: "عکس زنده", other: "سایر" })[type] || type;
}
async function addMessage(env, data) {
  const now = NOW();
  const insertResult = await run(env.DB, `INSERT OR IGNORE INTO messages
    (update_id, conversation_id, sender_id, recipient_id, source_chat_id, source_message_id,
     message_type, text_content, caption, is_admin_message, metadata_json, created_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`,
    String(data.updateId), String(data.conversationId), String(data.senderId), String(data.recipientId),
    data.sourceChatId == null ? null : String(data.sourceChatId), data.sourceMessageId == null ? null : Number(data.sourceMessageId),
    data.type || "text", data.textContent ?? null, data.caption ?? null, Number(Boolean(data.isAdminMessage)),
    JSON.stringify(data.metadata || {}), now);
  const message = await first(env.DB, `SELECT * FROM messages WHERE update_id=?`, String(data.updateId));
  if (!message) throw new Error("Message insert failed: row could not be reloaded.");
  const id = Number(message.id);
  // Always resume the persisted recipient/conversation; never reroute a retried Update to a newer active chat.
  await run(env.DB, `INSERT OR IGNORE INTO message_deliveries
    (message_id,recipient_id,status,attempts,next_attempt_at,created_at) VALUES(?,?,'pending',0,0,?)`, id, String(message.recipient_id), now);
  await run(env.DB, `UPDATE conversations SET updated_at=?, last_message_at=? WHERE id=?`, now, now, String(message.conversation_id));
  return { id, isNew: Number(insertResult?.meta?.changes || 0) > 0, message };
}
async function addAdminMessage(env, updateId, conversation, senderId, recipientId, text) {
  const idKey = `admin-send:${updateId}`;
  return addMessage(env, {
    updateId: idKey, conversationId: conversation.id, senderId, recipientId,
    sourceChatId: null, sourceMessageId: null, type: "text", textContent: text,
    isAdminMessage: true, metadata: { origin: "admin_send" }
  });
}
async function enqueueIncomingAdminAlert(env, messageId, ctx, conversation, recipientId) {
  const senderId = String(ctx.from.id);
  const sender = await getUser(env, senderId);
  const recipient = await getUser(env, recipientId);
  const message = ctx.message;
  const original = shortText(message.text ?? message.caption ?? `[${typeFa(messageType(message))}]`, 460);
  const alert = [
    `📨 <b>پیام جدید در ربات</b>`,
    quote(original || "رسانه یا پیام بدون متن"),
    `🆔 شناسه پیام: ${code(`#M${messageId}`)}`,
    `👤 فرستنده: <a href="${profileUrl(senderId)}">${escapeHtml(userName(sender))}</a>`,
    `🆔 شناسه تلگرام فرستنده: ${code(senderId)}`,
    `🔗 نام کاربری: ${usernameText(sender)}`,
    `🎯 گیرنده: ${code(recipientId)}${recipient?.username ? ` (${usernameText(recipient)})` : ""}`,
    `🧵 گفتگو: ${code(conversation.id)}`,
    `📦 نوع: <b>${escapeHtml(typeFa(messageType(message)))}</b>`,
    `🕒 زمان: ${code(dateText(NOW(), env))}`
  ].join("\n");
  const keyboard = { inline_keyboard: [
    [{ text: "↩️ پاسخ مستقیم به فرستنده", callback_data: `admin:reply:${senderId}` }],
    [{ text: "👤 پروفایل فرستنده", callback_data: `admin:user:${senderId}` }, { text: "📜 تاریخچه", callback_data: `admin:history:${senderId}` }],
    [{ text: "🚫 مسدودسازی کاربر", callback_data: `admin:block:${senderId}` }]
  ] };
  const admins = await listAdminIds(env);
  for (const adminId of admins) {
    await enqueueNotification(env, `admin-message:${messageId}:${adminId}`, adminId, alert, keyboard);
  }
}
async function recordIncoming(ctx, env) {
  const userId = String(ctx.from.id);
  const message = ctx.message;
  if (ctx.chat?.type !== "private") {
    await safeReply(ctx, `این ربات فقط در گفت‌وگوی خصوصی کار می‌کند. ${quote("لطفاً ربات را در Private باز کنید.")}`);
    return;
  }
  if (message.text?.startsWith("/")) {
    await safeReply(ctx, `دستور ناشناخته است. برای راهنما ${code("/help")} را بفرستید.`);
    return;
  }
  // Idempotent resume path: if D1 committed the message before a transient failure, do not route it again.
  const prior = await first(env.DB, `SELECT * FROM messages WHERE update_id=?`, String(ctx.update.update_id));
  if (prior) {
    await run(env.DB, `INSERT OR IGNORE INTO message_deliveries(message_id,recipient_id,status,attempts,next_attempt_at,created_at)
      VALUES(?,?,'pending',0,0,?)`, prior.id, String(prior.recipient_id), NOW());
    await enqueueNotification(env, `message-ack:${prior.id}`, userId,
      `✅ <b>پیام ثبت شد</b>\n${quote("پیام شما در صف تحویل قرار گرفت.")}\n🆔 شناسه پیام: ${code(`#M${prior.id}`)}\n🕒 ${code(dateText(prior.created_at, env))}`);
    if (!prior.is_admin_message) {
      const priorConversation = await getConversation(env, prior.conversation_id);
      await enqueueIncomingAdminAlert(env, prior.id, ctx, priorConversation, prior.recipient_id);
    }
    return;
  }
  const sender = await getUser(env, userId);
  if (sender?.is_banned) {
    await safeReply(ctx, `⛔ دسترسی این حساب به ربات محدود شده است.`);
    return;
  }
  if (!(await isAdmin(env, userId)) && !(await limited(env, userId))) {
    await safeReply(ctx, `⏳ تعداد پیام‌های شما در این دقیقه بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.`);
    return;
  }
  let conversation = await activeConversation(env, userId);
  let recipientId;
  if (!conversation) {
    if (await isAdmin(env, userId)) {
      await safeReply(ctx, `برای پیام مستقیم از دستور ${code("/send USER_ID MESSAGE")} استفاده کنید یا ابتدا از دکمهٔ پاسخ در یک پیام وارد گفتگو شوید.`);
      return;
    }
    await ensureUserStub(env, env.ADMIN_ID);
    conversation = await getOrCreateConversation(env, userId, String(env.ADMIN_ID), userId);
    await setActiveConversation(env, userId, conversation.id);
    recipientId = String(env.ADMIN_ID);
  } else {
    recipientId = otherParticipant(conversation, userId);
  }
  if (await isBlockedBetween(env, conversation.id, recipientId, userId)) {
    await safeReply(ctx, `⛔ این گفتگو توسط مخاطب مسدود شده است. پیام شما ارسال نشد.`);
    return;
  }
  if (await isBlockedBetween(env, conversation.id, userId, recipientId)) {
    await safeReply(ctx, `⛔ شما این گفتگو را مسدود کرده‌اید. برای ادامه ابتدا آن را از ${code("/blocklist")} مدیریت کنید.`);
    return;
  }
  const recipient = await getUser(env, recipientId);
  if (recipient?.is_banned) {
    await safeReply(ctx, `⛔ این مقصد در حال حاضر در دسترس نیست.`);
    return;
  }
  const type = messageType(message);
  const textContent = message.text ?? null;
  const caption = message.caption ?? null;
  const isAdminMessage = await isAdmin(env, userId);
  const data = await addMessage(env, {
    updateId: ctx.update.update_id,
    conversationId: conversation.id,
    senderId: userId,
    recipientId,
    sourceChatId: ctx.chat.id,
    sourceMessageId: message.message_id,
    type,
    textContent,
    caption,
    isAdminMessage,
    metadata: { telegram_message_id: message.message_id, chat_type: ctx.chat.type }
  });
  const persistedConversation = await getConversation(env, data.message.conversation_id);
  await enqueueNotification(env, `message-ack:${data.id}`, userId,
    `✅ <b>پیام ثبت شد</b>\n${quote("پیام شما در صف تحویل قرار گرفت. در صورت مسدود بودن ربات توسط مخاطب، نتیجهٔ ناموفق برای شما ثبت می‌شود.")}\n🆔 شناسه پیام: ${code(`#M${data.id}`)}\n🕒 ${code(dateText(data.message.created_at, env))}`);
  if (!data.message.is_admin_message) await enqueueIncomingAdminAlert(env, data.id, ctx, persistedConversation, data.message.recipient_id);
  if (data.isNew) await audit(env, userId, "message_created", data.message.recipient_id, data.id, { conversation_id: data.message.conversation_id, type: data.message.message_type });
}

async function safeReply(ctx, text, options = {}) {
  try {
    return await ctx.reply(text, { parse_mode: "HTML", ...options });
  } catch (error) {
    console.error("Telegram reply failed", telegramErrorText(error));
    return null;
  }
}
async function safeAnswer(ctx, text = "", options = {}) {
  try { await ctx.answerCallbackQuery({ text: text || undefined, ...options }); }
  catch (error) { console.error("Callback answer failed", telegramErrorText(error)); }
}
async function safeEdit(ctx, text, options = {}) {
  try { return await ctx.editMessageText(text, { parse_mode: "HTML", ...options }); }
  catch (error) { return null; }
}
async function isMaintenance(env) { return (await getSetting(env, "maintenance", "0")) === "1"; }

function homeKeyboard(isAdminUser = false) {
  const rows = [
    [{ text: "🔗 لینک ناشناس من", callback_data: "menu:link" }, { text: "📥 پیام‌های دریافتی", callback_data: "menu:inbox:1" }],
    [{ text: "📜 تاریخچه", callback_data: "menu:history:1" }, { text: "👤 پروفایل من", callback_data: "menu:me" }],
    [{ text: "🚫 فهرست مسدودها", callback_data: "menu:blocklist" }, { text: "❔ راهنما", callback_data: "menu:help" }]
  ];
  if (isAdminUser) rows.push([{ text: "🛠 پنل مدیریت", callback_data: "admin:home" }]);
  return { inline_keyboard: rows };
}
function welcomeText(env, userId) {
  return `🌙 <b>${escapeHtml(env.BOT_TITLE || "چت ناشناس")}</b>\n` +
    `${quote("پیام ناشناس دریافت کنید و از طریق ربات به همان گفتگو پاسخ بدهید.")}\n` +
    `🆔 شناسهٔ تلگرام شما: ${code(userId)}\n\n` +
    `🔹 <b>شروع سریع</b>\n` +
    `• لینک اختصاصی را بسازید و برای دیگران بفرستید.\n` +
    `• با باز کردن لینک، فرستنده می‌تواند به شما پیام بدهد.\n` +
    `• برای پاسخ، دکمهٔ «پاسخ به این گفتگو» را در پیام دریافتی بزنید.\n` +
    `• شناسهٔ هر پیام با قالب ${code("#M123")} در تاریخچه نمایش داده می‌شود.\n\n` +
    `🔐 <i>هویت فرستنده برای مخاطب عادی مخفی می‌ماند؛ مدیر سامانه برای مقابله با سوءاستفاده به شناسه‌های فنی دسترسی دارد.</i>`;
}
function helpText() {
  return `📚 <b>راهنمای ربات</b>\n${quote("برای درست کار کردن پاسخ‌ها، هنگام دریافت پیام از دکمهٔ «پاسخ به این گفتگو» استفاده کنید.")}\n\n` +
    `<b>کاربرها</b>\n` +
    `${code("/start")} — شروع ربات\n${code("/link")} — لینک شخصی\n${code("/inbox [page]")} — پیام‌های دریافتی با شناسه\n` +
    `${code("/history [page]")} — تاریخچهٔ ارسال و دریافت\n${code("/me")} — پروفایل و آمار\n${code("/clearhistory [conversation_id]")} — پنهان‌کردن تاریخچه از حساب خودتان\n` +
    `${code("/deleteboth MESSAGE_ID")} — درخواست حذف دوطرفهٔ یک پیام\n${code("/blocklist")} — گفتگوهای مسدود\n${code("/unblockchat CONVERSATION_ID")} — رفع مسدودی گفتگو\n${code("/cancel")} — لغو انتخاب گفتگوی فعال\n\n` +
    `<b>مدیریت ربات</b>\n${code("/admin")}، ${code("/users [page]")}، ${code("/user ID")}، ${code("/history_admin ID [page]")}، ${code("/recent [page]")}، ${code("/stats")}، ${code("/search QUERY")}، ${code("/audit [page]")}، ${code("/errors")}، ${code("/send ID TEXT")}، ${code("/broadcast TEXT")}، ${code("/block ID")}، ${code("/unblock ID")}\n\n` +
    `<i>پاک‌کردن تاریخچه فقط نمایش آن را برای همان حساب پنهان می‌کند. حذف دوطرفه از دیتابیس و از نسخه‌های ارسالی ربات تلاش می‌کند پیام را پاک کند؛ حذف از تلگرام برای پیام‌های قدیمی یا پیام‌هایی که دیگر قابل حذف نیستند تضمین‌پذیر نیست.</i>`;
}

async function showLink(ctx, env) {
  const id = String(ctx.from.id);
  const startNow = NOW();
  await run(env.DB, `UPDATE users SET started_at=COALESCE(started_at, ?), last_seen_at=?, updated_at=? WHERE id=?`, startNow, startNow, startNow, id);
  const token = await ensureLink(env, id);
  const url = linkUrl(env, token);
  await safeReply(ctx, `🔗 <b>لینک اختصاصی شما</b>\n${quote("هرکس این لینک را باز کند می‌تواند پیام ناشناس برای شما بفرستد.")}\n${code(url)}\n\n🛡 لینک را فقط با کسانی به اشتراک بگذارید که می‌خواهید از آن‌ها پیام دریافت کنید.`, {
    reply_markup: { inline_keyboard: [[{ text: "↗️ بازکردن لینک", url }], [{ text: "🏠 منوی اصلی", callback_data: "menu:home" }]] }
  });
}
async function showUserStats(ctx, env, userId = String(ctx.from.id), adminView = false) {
  const user = await getUser(env, userId);
  if (!user) { await safeReply(ctx, `کاربر ${code(userId)} هنوز در ربات ثبت نشده است.`); return; }
  const stats = await first(env.DB, `SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN sender_id=? THEN 1 ELSE 0 END) AS outgoing,
      SUM(CASE WHEN recipient_id=? THEN 1 ELSE 0 END) AS incoming,
      SUM(CASE WHEN deleted_for_both_at IS NOT NULL THEN 1 ELSE 0 END) AS deleted
    FROM messages WHERE sender_id=? OR recipient_id=?`, String(userId), String(userId), String(userId), String(userId));
  const token = user.link_token || (adminView ? null : await ensureLink(env, userId));
  const link = token ? linkUrl(env, token) : null;
  const heading = adminView ? "👤 <b>پروفایل کاربر</b>" : "👤 <b>پروفایل من</b>";
  const rows = [heading,
    `نام: ${escapeHtml(userName(user))}`,
    `شناسهٔ تلگرام: ${code(user.id)}`,
    `نام کاربری: ${usernameText(user)}`,
    `زبان: ${code(user.language_code || "نامشخص")}`,
    `Premium: ${user.is_premium ? "بله" : "خیر"}`,
    `شروع ربات: ${code(dateText(user.started_at || user.created_at, env))}`,
    `آخرین فعالیت: ${code(dateText(user.last_seen_at, env))}`,
    `📥 پیام‌های دریافتی: <b>${Number(stats?.incoming || 0)}</b>` ,
    `📤 پیام‌های ارسالی: <b>${Number(stats?.outgoing || 0)}</b>`,
    `🧹 پیام‌های حذف‌شدهٔ دوطرفه: <b>${Number(stats?.deleted || 0)}</b>`,
    `🚦 وضعیت: ${user.is_banned ? "مسدود توسط مدیر" : user.bot_blocked_at ? "ربات را بلاک کرده/دسترسی ندارد" : "عادی"}`,
    `🔗 لینک شخصی: ${link ? `<a href="${escapeHtml(link)}">بازکردن لینک</a> · ${code(link)}` : "کاربر هنوز با ربات شروع نکرده است"}`
  ];
  if (adminView) rows.push(`🔎 پروفایل تلگرام: <a href="${profileUrl(user.id)}">بازکردن پروفایل</a>`);
  await safeReply(ctx, rows.join("\n"), { reply_markup: { inline_keyboard: [
    [{ text: "📜 تاریخچهٔ این کاربر", callback_data: `admin:history:${user.id}` }],
    ...(adminView ? [[{ text: user.is_banned ? "✅ رفع مسدودی" : "🚫 مسدودسازی", callback_data: `admin:${user.is_banned ? "unblock" : "block"}:${user.id}` }]] : []),
    [{ text: "🏠 منوی اصلی", callback_data: "menu:home" }]
  ] } });
}
async function showHistory(ctx, env, userId, page = 1, adminView = false, inboxOnly = false) {
  const pageSize = inboxOnly ? 5 : 8;
  const offset = (page - 1) * pageSize;
  const filter = inboxOnly ? `m.recipient_id=?` : `(m.sender_id=? OR m.recipient_id=?)`;
  const values = inboxOnly ? [String(userId), String(userId), pageSize, offset] : [String(userId), String(userId), String(userId), pageSize, offset];
  const sql = `SELECT m.*, d.status AS delivery_status FROM messages m
    LEFT JOIN message_deliveries d ON d.message_id=m.id AND d.recipient_id=m.recipient_id
    WHERE ${filter} AND m.deleted_for_both_at IS NULL
      AND NOT EXISTS(SELECT 1 FROM user_message_visibility v WHERE v.user_id=? AND v.message_id=m.id)
    ORDER BY m.id DESC LIMIT ? OFFSET ?`;
  let rows = await all(env.DB, sql, ...values);
  // For inbox, the extra visibility user id is the second placeholder; for history it is the third.
  if (rows.length === 0) {
    await safeReply(ctx, inboxOnly ? "📥 <b>صندوق پیام خالی است.</b>" : "📜 <b>تاریخچه‌ای برای نمایش وجود ندارد.</b>", {
      reply_markup: { inline_keyboard: [[{ text: "🏠 منوی اصلی", callback_data: "menu:home" }]] }
    });
    return;
  }
  const lines = [inboxOnly ? `📥 <b>پیام‌های دریافتی — صفحه ${page}</b>` : `📜 <b>تاریخچه — صفحه ${page}</b>`, quote("شناسهٔ فنی پیام برای پیگیری استفاده می‌شود؛ هویت فرستنده برای کاربر عادی نمایش داده نمی‌شود.")];
  const keyboard = [];
  for (const row of rows) {
    const outgoing = String(row.sender_id) === String(userId);
    const status = deliveryStatusFa(row.delivery_status);
    const body = shortText(row.text_content ?? row.caption ?? `[${typeFa(row.message_type)}]`, 110);
    lines.push(`\n${outgoing ? "📤 ارسال‌شده" : "📥 دریافتی"} · ${code(`#M${row.id}`)}\n${quote(body || "پیام رسانه‌ای") }\n📦 ${escapeHtml(typeFa(row.message_type))} · وضعیت: ${escapeHtml(status)}\n🕒 ${code(dateText(row.created_at, env))}${adminView ? `\n👤 ${code(row.sender_id)} → 🎯 ${code(row.recipient_id)}` : ""}`);
    if (!adminView) {
      keyboard.push([{ text: `↩️ پاسخ به #M${row.id}`, callback_data: `reply:${row.conversation_id}` }, { text: `🗑 حذف دوطرفه #M${row.id}`, callback_data: `delboth:${row.id}` }]);
    } else {
      keyboard.push([{ text: `👤 فرستنده ${row.sender_id}`, callback_data: `admin:user:${row.sender_id}` }, { text: `🎯 گیرنده ${row.recipient_id}`, callback_data: `admin:user:${row.recipient_id}` }]);
    }
  }
  const previous = Math.max(1, page - 1), next = page + 1;
  if (page > 1 || rows.length === pageSize) {
    keyboard.push([
      ...(page > 1 ? [{ text: "⬅️ قبلی", callback_data: `${inboxOnly ? "menu:inbox" : adminView ? "admin:historypage" : "menu:history"}:${inboxOnly ? previous : adminView ? `${userId}:${previous}` : previous}` }] : []),
      ...(rows.length === pageSize ? [{ text: "بعدی ➡️", callback_data: `${inboxOnly ? "menu:inbox" : adminView ? "admin:historypage" : "menu:history"}:${inboxOnly ? next : adminView ? `${userId}:${next}` : next}` }] : [])
    ]);
  }
  keyboard.push([{ text: "🏠 منوی اصلی", callback_data: "menu:home" }]);
  await safeReply(ctx, lines.join("\n"), { reply_markup: { inline_keyboard: keyboard } });
}
async function showBlocklist(ctx, env, userId) {
  const rows = await all(env.DB, `SELECT b.conversation_id, b.blocked_id, b.created_at, c.last_message_at
    FROM conversation_blocks b JOIN conversations c ON c.id=b.conversation_id
    WHERE b.blocker_id=? ORDER BY b.created_at DESC LIMIT 50`, String(userId));
  if (!rows.length) {
    await safeReply(ctx, `✅ <b>فهرست گفتگوهای مسدود خالی است.</b>`, { reply_markup: { inline_keyboard: [[{ text: "🏠 منوی اصلی", callback_data: "menu:home" }]] } });
    return;
  }
  const lines = [`🚫 <b>گفتگوهای مسدودشده</b>`, quote("برای حفظ ناشناس‌بودن، اینجا شناسهٔ تلگرام طرف مقابل نمایش داده نمی‌شود.")];
  const keyboard = [];
  for (const row of rows) {
    lines.push(`\nگفتگو: ${code(row.conversation_id)}\nتاریخ مسدودی: ${code(dateText(row.created_at, env))}`);
    keyboard.push([{ text: `🔓 رفع مسدودی ${row.conversation_id.slice(0, 6)}`, callback_data: `unblockchat:${row.conversation_id}` }]);
  }
  keyboard.push([{ text: "🏠 منوی اصلی", callback_data: "menu:home" }]);
  await safeReply(ctx, lines.join("\n"), { reply_markup: { inline_keyboard: keyboard } });
}

async function showAdminHome(ctx, env) {
  if (!(await isAdmin(env, ctx.from.id))) { await safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); return; }
  const stats = await getGlobalStats(env);
  const text = `🛠 <b>پنل مدیریت</b>\n${quote("گزارش‌ها و عملیات مدیریتی در این بخش ثبت و قابل پیگیری است.")}\n\n` +
    `👥 کاربران: <b>${stats.users}</b>\n🧵 گفتگوها: <b>${stats.conversations}</b>\n💬 پیام‌ها: <b>${stats.messages}</b>\n` +
    `✅ تحویل موفق: <b>${stats.sent}</b> · ⚠️ ناموفق: <b>${stats.failed}</b>\n🚫 کاربران مسدودشده: <b>${stats.banned}</b>\n` +
    `⏱ پیام‌های یک ساعت اخیر: <b>${stats.lastHour}</b>\n🕒 ${code(dateText(NOW(), env))}`;
  await safeReply(ctx, text, { reply_markup: { inline_keyboard: [
    [{ text: "👥 کاربران", callback_data: "admin:users:1" }, { text: "📊 آمار", callback_data: "admin:stats" }],
    [{ text: "🕘 پیام‌های اخیر", callback_data: "admin:recent:1" }, { text: "⚠️ خطاها", callback_data: "admin:errors" }],
    [{ text: "🧾 Audit log", callback_data: "admin:audit:1" }, { text: "🚫 کاربران مسدود", callback_data: "admin:blocked:1" }],
    [{ text: "📢 راهنمای Broadcast", callback_data: "admin:broadcast_help" }],
    [{ text: "🏠 منوی اصلی", callback_data: "menu:home" }]
  ] } });
}
async function getGlobalStats(env) {
  const row = await first(env.DB, `SELECT
    (SELECT COUNT(*) FROM users) users,
    (SELECT COUNT(*) FROM conversations) conversations,
    (SELECT COUNT(*) FROM messages) messages,
    (SELECT COUNT(*) FROM message_deliveries WHERE status='sent') sent,
    (SELECT COUNT(*) FROM message_deliveries WHERE status IN ('failed','blocked')) failed,
    (SELECT COUNT(*) FROM users WHERE is_banned=1) banned,
    (SELECT COUNT(*) FROM messages WHERE julianday(created_at) >= julianday('now','-1 hour')) lastHour`);
  return Object.fromEntries(Object.entries(row || {}).map(([k, v]) => [k, Number(v || 0)]));
}
async function showUsers(ctx, env, page = 1) {
  if (!(await isAdmin(env, ctx.from.id))) { await safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); return; }
  const size = 8, offset = (page - 1) * size;
  const rows = await all(env.DB, `SELECT u.*, (SELECT COUNT(*) FROM messages m WHERE m.sender_id=u.id) outgoing,
      (SELECT COUNT(*) FROM messages m WHERE m.recipient_id=u.id) incoming
    FROM users u ORDER BY u.last_seen_at DESC LIMIT ? OFFSET ?`, size, offset);
  const total = Number((await first(env.DB, `SELECT COUNT(*) AS n FROM users`))?.n || 0);
  if (!rows.length) { await safeReply(ctx, `در صفحهٔ ${page} کاربری وجود ندارد.`, { reply_markup: { inline_keyboard: [[{ text: "⬅️ صفحهٔ قبل", callback_data: `admin:users:${Math.max(1, page - 1)}` }, { text: "🛠 پنل مدیریت", callback_data: "admin:home" }]] } }); return; }
  const lines = [`👥 <b>فهرست کاربران</b> · صفحه ${page}`, quote(`تعداد کل کاربران: ${total}. شناسه‌ها با فرمت monospace مشخص شده‌اند.`)];
  const keyboard = [];
  for (const user of rows) {
    lines.push(`\n👤 ${escapeHtml(userName(user))}\n🆔 ${code(user.id)} · ${usernameText(user)}\n📥 ${Number(user.incoming)} دریافتی · 📤 ${Number(user.outgoing)} ارسالی\n🕒 ${code(dateText(user.last_seen_at, env))}${user.is_banned ? " · 🚫 مسدود" : ""}`);
    keyboard.push([{ text: `👤 ${String(user.first_name || user.username || user.id).slice(0, 22)}`, callback_data: `admin:user:${user.id}` }, { text: `📜 تاریخچه`, callback_data: `admin:history:${user.id}` }]);
  }
  const navRow = [
    ...(page > 1 ? [{ text: "⬅️ قبلی", callback_data: `admin:users:${page - 1}` }] : []),
    ...(offset + rows.length < total ? [{ text: "بعدی ➡️", callback_data: `admin:users:${page + 1}` }] : [])
  ];
  if (navRow.length) keyboard.push(navRow);
  keyboard.push([{ text: "🛠 پنل مدیریت", callback_data: "admin:home" }]);
  await safeReply(ctx, lines.join("\n"), { reply_markup: { inline_keyboard: keyboard } });
}
async function showAdminStats(ctx, env) {
  const stats = await getGlobalStats(env);
  const types = await all(env.DB, `SELECT message_type, COUNT(*) AS n FROM messages GROUP BY message_type ORDER BY n DESC LIMIT 12`);
  const errorCount = Number((await first(env.DB, `SELECT COUNT(*) n FROM app_errors WHERE julianday(created_at) >= julianday('now','-24 hours')`))?.n || 0);
  const pendingUpdates = Number((await first(env.DB, `SELECT COUNT(*) n FROM webhook_updates WHERE status IN ('pending','processing')`))?.n || 0);
  const pendingDeliveries = Number((await first(env.DB, `SELECT COUNT(*) n FROM message_deliveries WHERE status IN ('pending','processing')`))?.n || 0);
  const lines = [`📊 <b>آمار دقیق ربات</b>`, quote("آمار پیام‌ها بر اساس رکوردهای پیام است، نه تعداد لینک‌ها یا گفتگوها."),
    `👥 کاربران: ${code(stats.users)}`, `🧵 گفتگوها: ${code(stats.conversations)}`, `💬 کل پیام‌های ثبت‌شده: ${code(stats.messages)}`,
    `📥 کل تحویل موفق: ${code(stats.sent)}`, `⚠️ تحویل ناموفق/مسدود: ${code(stats.failed)}`, `🚫 مسدودشده توسط مدیریت: ${code(stats.banned)}`,
    `🕐 پیام‌های ساعت اخیر: ${code(stats.lastHour)}`, `🔁 Updateهای در صف/پردازش: ${code(pendingUpdates)}`,
    `📤 تحویل‌های در صف/پردازش: ${code(pendingDeliveries)}`, `🧯 خطاهای ۲۴ ساعت اخیر: ${code(errorCount)}`, `\n<b>دسته‌بندی پیام‌ها</b>`];
  for (const row of types) lines.push(`• ${escapeHtml(typeFa(row.message_type))}: ${code(row.n)}`);
  await safeReply(ctx, lines.join("\n"), { reply_markup: { inline_keyboard: [[{ text: "🔄 بروزرسانی", callback_data: "admin:stats" }], [{ text: "🛠 پنل مدیریت", callback_data: "admin:home" }]] } });
}
async function showUserAdmin(ctx, env, userId) {
  if (!(await isAdmin(env, ctx.from.id))) { await safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); return; }
  const id = parseTelegramId(userId);
  if (!id) { await safeReply(ctx, `شناسه نامعتبر است. نمونه: ${code("/user 381200758")}`); return; }
  await showUserStats(ctx, env, id, true);
}
async function showAdminHistory(ctx, env, userId, page = 1) {
  if (!(await isAdmin(env, ctx.from.id))) { await safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); return; }
  const target = parseTelegramId(userId);
  if (!target) { await safeReply(ctx, `شناسه نامعتبر است. نمونه: ${code("/history_admin 123456 1")}`); return; }
  const size = 8, offset = (page - 1) * size;
  const rows = await all(env.DB, `SELECT m.*, d.status AS delivery_status FROM messages m
    LEFT JOIN message_deliveries d ON d.message_id=m.id AND d.recipient_id=m.recipient_id
    WHERE m.sender_id=? OR m.recipient_id=? ORDER BY m.id DESC LIMIT ? OFFSET ?`, target, target, size, offset);
  if (!rows.length) { await safeReply(ctx, `📭 پیام مرتبطی برای کاربر ${code(target)} پیدا نشد.`); return; }
  const user = await getUser(env, target);
  const lines = [`📜 <b>تاریخچهٔ کاربر</b>`, `👤 ${escapeHtml(userName(user))} · ${code(target)} · صفحه ${page}`];
  const keyboard = [];
  for (const m of rows) {
    const removed = Boolean(m.deleted_for_both_at);
    const content = removed ? "[حذف‌شده از هر دو طرف]" : shortText(m.text_content ?? m.caption ?? `[${typeFa(m.message_type)}]`, 130);
    lines.push(`\n🆔 ${code(`#M${m.id}`)} · ${code(m.sender_id)} → ${code(m.recipient_id)}\n${quote(content)}\n📦 ${escapeHtml(typeFa(m.message_type))} · ${escapeHtml(deliveryStatusFa(m.delivery_status))}\n🕒 ${code(dateText(m.created_at, env))}`);
    keyboard.push([{ text: `👤 ${m.sender_id}`, callback_data: `admin:user:${m.sender_id}` }, { text: `👤 ${m.recipient_id}`, callback_data: `admin:user:${m.recipient_id}` }]);
  }
  keyboard.push([
    ...(page > 1 ? [{ text: "⬅️ قبلی", callback_data: `admin:historypage:${target}:${page - 1}` }] : []),
    ...(rows.length === size ? [{ text: "بعدی ➡️", callback_data: `admin:historypage:${target}:${page + 1}` }] : [])
  ]);
  keyboard.push([{ text: "👤 پروفایل کاربر", callback_data: `admin:user:${target}` }, { text: "🛠 پنل", callback_data: "admin:home" }]);
  await safeReply(ctx, lines.join("\n"), { reply_markup: { inline_keyboard: keyboard } });
}
async function showRecent(ctx, env, page = 1) {
  if (!(await isAdmin(env, ctx.from.id))) { await safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); return; }
  const size = 8, offset = (page - 1) * size;
  const rows = await all(env.DB, `SELECT m.*, d.status AS delivery_status FROM messages m
    LEFT JOIN message_deliveries d ON d.message_id=m.id AND d.recipient_id=m.recipient_id ORDER BY m.id DESC LIMIT ? OFFSET ?`, size, offset);
  const lines = [`🕘 <b>آخرین پیام‌های سامانه</b> · صفحه ${page}`];
  const keyboard = [];
  for (const m of rows) {
    lines.push(`\n🆔 ${code(`#M${m.id}`)} · ${code(m.sender_id)} → ${code(m.recipient_id)}\n${quote(m.deleted_for_both_at ? "[حذف دوطرفه]" : shortText(m.text_content ?? m.caption ?? `[${typeFa(m.message_type)}]`, 100))}\n📦 ${escapeHtml(typeFa(m.message_type))} · ${escapeHtml(deliveryStatusFa(m.delivery_status))} · ${code(dateText(m.created_at, env))}`);
    keyboard.push([{ text: `👤 ${m.sender_id}`, callback_data: `admin:user:${m.sender_id}` }, { text: `📜 تاریخچه`, callback_data: `admin:history:${m.sender_id}` }]);
  }
  keyboard.push([
    ...(page > 1 ? [{ text: "⬅️ قبلی", callback_data: `admin:recent:${page - 1}` }] : []),
    ...(rows.length === size ? [{ text: "بعدی ➡️", callback_data: `admin:recent:${page + 1}` }] : [])
  ]);
  keyboard.push([{ text: "🛠 پنل مدیریت", callback_data: "admin:home" }]);
  await safeReply(ctx, lines.join("\n"), { reply_markup: { inline_keyboard: keyboard } });
}
async function showAudit(ctx, env, page = 1) {
  const size = 8, offset = (page - 1) * size;
  const rows = await all(env.DB, `SELECT * FROM audit_logs ORDER BY id DESC LIMIT ? OFFSET ?`, size, offset);
  if (!rows.length) { await safeReply(ctx, "🧾 هنوز رویداد مدیریتی ثبت نشده است."); return; }
  const lines = [`🧾 <b>Audit log</b> · صفحه ${page}`];
  const keyboard = [];
  for (const row of rows) {
    lines.push(`\n${code(`#A${row.id}`)} · <b>${escapeHtml(row.action)}</b>\nActor: ${code(row.actor_id || "system")} · Target: ${code(row.target_id || "—")}\nMessage: ${code(row.message_id == null ? "—" : `#M${row.message_id}`)}\n🕒 ${code(dateText(row.created_at, env))}\n${quote(shortText(row.details_json, 130))}`);
    if (row.target_id && /^\d+$/.test(row.target_id)) keyboard.push([{ text: `👤 ${row.target_id}`, callback_data: `admin:user:${row.target_id}` }]);
  }
  keyboard.push([
    ...(page > 1 ? [{ text: "⬅️ قبلی", callback_data: `admin:audit:${page - 1}` }] : []),
    ...(rows.length === size ? [{ text: "بعدی ➡️", callback_data: `admin:audit:${page + 1}` }] : [])
  ]);
  keyboard.push([{ text: "🛠 پنل مدیریت", callback_data: "admin:home" }]);
  await safeReply(ctx, lines.join("\n"), { reply_markup: { inline_keyboard: keyboard } });
}
async function showErrors(ctx, env) {
  const rows = await all(env.DB, `SELECT * FROM app_errors ORDER BY id DESC LIMIT 8`);
  if (!rows.length) { await safeReply(ctx, "✅ خطای ثبت‌شده‌ای وجود ندارد."); return; }
  const lines = [`⚠️ <b>آخرین خطاهای Worker</b>`];
  for (const e of rows) lines.push(`\n${code(`#E${e.id}`)} · ${escapeHtml(e.location)}\nUpdate: ${code(e.update_id || "—")}\n${quote(shortText(e.error_message, 240))}\n🕒 ${code(dateText(e.created_at, env))}`);
  await safeReply(ctx, lines.join("\n"), { reply_markup: { inline_keyboard: [[{ text: "🔄 بروزرسانی", callback_data: "admin:errors" }], [{ text: "🛠 پنل مدیریت", callback_data: "admin:home" }]] } });
}
async function showAdminBlocked(ctx, env, page = 1) {
  const size = 8, offset = (page - 1) * size;
  const rows = await all(env.DB, `SELECT id, username, first_name, last_name, bot_blocked_at, is_banned FROM users
    WHERE is_banned=1 OR bot_blocked_at IS NOT NULL ORDER BY updated_at DESC LIMIT ? OFFSET ?`, size, offset);
  if (!rows.length) { await safeReply(ctx, "✅ کاربر مسدود یا غیرقابل‌دسترسی ثبت نشده است."); return; }
  const lines = [`🚫 <b>کاربران محدود/غیرقابل‌دسترسی</b> · صفحه ${page}`], keyboard = [];
  for (const u of rows) {
    lines.push(`\n${escapeHtml(userName(u))} · ${code(u.id)} · ${usernameText(u)}\nمدیریت: ${u.is_banned ? "مسدود" : "آزاد"} · دسترسی ربات: ${u.bot_blocked_at ? "مسدود/غیرقابل‌دسترسی" : "فعال"}`);
    keyboard.push([{ text: `👤 ${u.id}`, callback_data: `admin:user:${u.id}` }, { text: u.is_banned ? "✅ رفع مسدودی" : "🚫 مسدودسازی", callback_data: `admin:${u.is_banned ? "unblock" : "block"}:${u.id}` }]);
  }
  keyboard.push([{ text: "🛠 پنل مدیریت", callback_data: "admin:home" }]);
  await safeReply(ctx, lines.join("\n"), { reply_markup: { inline_keyboard: keyboard } });
}

async function createDeleteJobs(env, message, deliveries) {
  const now = NOW();
  if (message.source_chat_id && message.source_message_id) {
    await run(env.DB, `INSERT OR IGNORE INTO delete_jobs(message_id,chat_id,telegram_message_id,status,attempts,next_attempt_at,created_at) VALUES(?,?,?,'pending',0,0,?)`,
      message.id, String(message.source_chat_id), Number(message.source_message_id), now);
  }
  for (const d of deliveries) {
    for (const telegramMessageId of [d.header_message_id, d.content_message_id]) {
      if (telegramMessageId) await run(env.DB, `INSERT OR IGNORE INTO delete_jobs(message_id,chat_id,telegram_message_id,status,attempts,next_attempt_at,created_at) VALUES(?,?,?,'pending',0,0,?)`,
        message.id, String(d.recipient_id), Number(telegramMessageId), now);
    }
  }
}
async function requestDeleteBoth(ctx, env, messageId) {
  const id = Number.parseInt(String(messageId).trim().replace(/^#?M/i, ""), 10);
  if (!Number.isSafeInteger(id) || id <= 0) { await safeReply(ctx, `شناسه پیام نامعتبر است. نمونه: ${code("/deleteboth 123")}`); return; }
  const msg = await first(env.DB, `SELECT * FROM messages WHERE id=?`, id);
  if (!msg) { await safeReply(ctx, `پیامی با شناسه ${code(`#M${id}`)} پیدا نشد.`); return; }
  const userId = String(ctx.from.id);
  const admin = await isAdmin(env, userId);
  if (!admin && msg.sender_id !== userId && msg.recipient_id !== userId) {
    await safeReply(ctx, "⛔ شما به این پیام دسترسی ندارید."); return;
  }
  if (msg.deleted_for_both_at) { await safeReply(ctx, `🗑 پیام ${code(`#M${id}`)} قبلاً از تاریخچهٔ سامانه حذف دوطرفه شده است.`); return; }
  await safeReply(ctx,
    `⚠️ <b>تأیید حذف دوطرفه</b>\n${quote("این کار متن پیام را از دیتابیس برنامه حذف می‌کند و برای حذف نسخه‌های ارسال‌شده توسط ربات از هر دو چت تلاش می‌کند. حذف پیام‌های قدیمی از خود تلگرام تضمین نیست.")}\nشناسه: ${code(`#M${id}`)}`,
    { reply_markup: { inline_keyboard: [
      [{ text: "🗑 تأیید حذف دوطرفه", callback_data: `delboth_yes:${id}` }, { text: "لغو", callback_data: `delboth_no:${id}` }]
    ] } });
}
async function executeDeleteBoth(ctx, env, messageId) {
  const id = Number.parseInt(String(messageId).trim().replace(/^#?M/i, ""), 10);
  const msg = await first(env.DB, `SELECT * FROM messages WHERE id=?`, id);
  if (!msg) { await safeAnswer(ctx, "پیام پیدا نشد.", { show_alert: true }); return; }
  const actorId = String(ctx.from.id);
  if (!(await isAdmin(env, actorId)) && msg.sender_id !== actorId && msg.recipient_id !== actorId) {
    await safeAnswer(ctx, "شما به این پیام دسترسی ندارید.", { show_alert: true }); return;
  }
  if (msg.deleted_for_both_at) { await safeAnswer(ctx, "این پیام قبلاً حذف شده است."); return; }
  const deliveries = await all(env.DB, `SELECT * FROM message_deliveries WHERE message_id=?`, id);
  await createDeleteJobs(env, msg, deliveries);
  await run(env.DB, `UPDATE messages SET deleted_for_both_at=?, text_content=NULL, caption=NULL,
    source_chat_id=NULL, source_message_id=NULL, metadata_json='{}' WHERE id=?`, NOW(), id);
  await audit(env, actorId, "message_deleted_for_both", null, id, { conversation_id: msg.conversation_id });
  const people = new Set([String(msg.sender_id), String(msg.recipient_id)]);
  for (const person of people) {
    await enqueueNotification(env, `delete-both-notice:${id}:${person}`, person,
      `🗑 <b>حذف دوطرفهٔ پیام</b>\n${quote("یک پیام از تاریخچهٔ هر دو طرف در سامانه حذف شد. ربات برای پاک‌کردن نسخه‌های قابل‌حذف تلگرام هم تلاش می‌کند.")}\nشناسه: ${code(`#M${id}`)}`);
  }
  await safeAnswer(ctx, "حذف دوطرفه در سامانه ثبت شد.");
  await safeReply(ctx, `🗑 حذف دوطرفهٔ ${code(`#M${id}`)} ثبت شد. پاک‌کردن نسخه‌های داخل تلگرام به محدودیت‌های Telegram وابسته است.`);
}
async function clearHistory(ctx, env, conversationId = null) {
  const userId = String(ctx.from.id);
  if (conversationId) {
    let conversation = await getConversation(env, conversationId);
    if (!conversation) {
      const options = await all(env.DB, `SELECT id FROM conversations WHERE id LIKE ? AND (user_a=? OR user_b=?) LIMIT 2`, `${conversationId}%`, userId, userId);
      if (options.length !== 1) { await safeReply(ctx, `شناسه گفتگو نامعتبر یا مبهم است. از ${code("/blocklist")} یا تاریخچه شناسه کامل را کپی کنید.`); return; }
      conversation = await getConversation(env, options[0].id);
    }
    if (conversation.user_a !== userId && conversation.user_b !== userId && !(await isAdmin(env, userId))) {
      await safeReply(ctx, "⛔ شما به این گفتگو دسترسی ندارید."); return;
    }
    await run(env.DB, `INSERT OR IGNORE INTO user_message_visibility(user_id,message_id,hidden_at)
      SELECT ?, id, ? FROM messages WHERE conversation_id=?`, userId, NOW(), conversation.id);
    await audit(env, userId, "history_cleared_for_user", conversation.id, null, { scope: "conversation" });
    await safeReply(ctx, `🧹 تاریخچهٔ گفتگوی ${code(conversation.id)} فقط از نمای حساب شما پنهان شد. تاریخچهٔ طرف مقابل پاک نشده است.`);
    return;
  }
  await run(env.DB, `INSERT OR IGNORE INTO user_message_visibility(user_id,message_id,hidden_at)
    SELECT ?, id, ? FROM messages WHERE sender_id=? OR recipient_id=?`, userId, NOW(), userId, userId);
  await audit(env, userId, "history_cleared_for_user", userId, null, { scope: "all_user_history" });
  await safeReply(ctx, `🧹 <b>تاریخچهٔ شما پاک‌سازی شد.</b>\n${quote("این عملیات پیام‌ها را فقط از فهرست شما پنهان می‌کند؛ طرف مقابل و ادمین ممکن است سوابق قبلی را داشته باشند. برای حذف یک پیام از هر دو طرف از /deleteboth MESSAGE_ID استفاده کنید.")}`);
}

async function setupHandlers(bot, env) {
  bot.use(async (ctx, next) => {
    if (ctx.from?.id) await upsertUser(env, ctx.from);
    if ((ctx.message || ctx.callbackQuery) && ctx.from?.id && ctx.chat?.type === "private" && !(await isAdmin(env, ctx.from.id)) && await isMaintenance(env)) {
      if (ctx.callbackQuery) await safeAnswer(ctx, "ربات موقتاً در حالت تعمیر است.", { show_alert: true });
      else if (ctx.message) await safeReply(ctx, `🛠 ${quote("ربات موقتاً در حالت تعمیر است. کمی بعد دوباره تلاش کنید.")}`);
      return;
    }
    await next();
  });

  bot.command("start", async (ctx) => {
    const userId = String(ctx.from.id);
    const startedNow = NOW();
    await run(env.DB, `UPDATE users SET bot_blocked_at=NULL, started_at=COALESCE(started_at, ?), last_seen_at=?, updated_at=? WHERE id=?`, startedNow, startedNow, startedNow, userId);
    await ensureLink(env, userId);
    const payload = String(ctx.message?.text || "").trim().split(/\s+/)[1] || "";
    if (payload) {
      const target = await first(env.DB, `SELECT * FROM users WHERE link_token=?`, payload);
      if (!target) { await safeReply(ctx, `⚠️ این لینک معتبر نیست یا دیگر وجود ندارد. از صاحب لینک بخواهید لینک جدید بسازد.`); return; }
      if (String(target.id) === userId) { await safeReply(ctx, `🙂 این لینک متعلق به خودتان است. از دکمهٔ لینک شخصی برای اشتراک‌گذاری استفاده کنید.`); return; }
      if (target.is_banned || target.bot_blocked_at) { await safeReply(ctx, `⚠️ این مقصد فعلاً در دسترس نیست و پیام قابل تحویل نیست.`); return; }
      const conversation = await getOrCreateConversation(env, userId, String(target.id), userId);
      if (await isBlockedBetween(env, conversation.id, String(target.id), userId)) { await safeReply(ctx, "⛔ صاحب لینک دریافت پیام از این گفتگو را مسدود کرده است."); return; }
      await setActiveConversation(env, userId, conversation.id);
      await audit(env, userId, "conversation_opened_by_link", target.id, null, { conversation_id: conversation.id });
      await safeReply(ctx, `🔗 <b>گفتگوی ناشناس آماده است</b>\n${quote("پیام بعدی شما برای صاحب لینک فرستاده می‌شود. هویت شما برای مخاطب نمایش داده نمی‌شود.")}\n🎯 مقصد: ${escapeHtml(userName(target))}\n🧵 کد گفتگو: ${code(conversation.id)}\n\nبرای ارسال، پیام یا رسانهٔ خود را همین‌جا بفرستید.`, {
        reply_markup: { inline_keyboard: [[{ text: "✍️ انتخاب این گفتگو", callback_data: `reply:${conversation.id}` }], [{ text: "🏠 منوی اصلی", callback_data: "menu:home" }]] }
      });
      return;
    }
    await ensureLink(env, userId);
    await safeReply(ctx, welcomeText(env, userId), { reply_markup: homeKeyboard(await isAdmin(env, userId)) });
  });

  bot.command("link", async (ctx) => showLink(ctx, env));
  bot.command("help", async (ctx) => safeReply(ctx, helpText(), { reply_markup: { inline_keyboard: [[{ text: "🏠 منوی اصلی", callback_data: "menu:home" }]] } }));
  bot.command("me", async (ctx) => showUserStats(ctx, env));
  bot.command("history", async (ctx) => showHistory(ctx, env, String(ctx.from.id), asPage(ctx.match), false, false));
  bot.command("inbox", async (ctx) => showHistory(ctx, env, String(ctx.from.id), asPage(ctx.match), false, true));
  bot.command("clearhistory", async (ctx) => clearHistory(ctx, env, String(ctx.match || "").trim() || null));
  bot.command("clear", async (ctx) => clearHistory(ctx, env, String(ctx.match || "").trim() || null));
  bot.command("deleteboth", async (ctx) => requestDeleteBoth(ctx, env, String(ctx.match || "").trim()));
  bot.command("cancel", async (ctx) => {
    await run(env.DB, `DELETE FROM user_states WHERE user_id=?`, String(ctx.from.id));
    await safeReply(ctx, `✅ گفتگوی فعال لغو شد. برای انتخاب دوباره روی دکمهٔ پاسخ در پیام دریافتی بزنید یا لینک جدیدی باز کنید.`);
  });
  bot.command("blocklist", async (ctx) => showBlocklist(ctx, env, String(ctx.from.id)));
  bot.command("unblockchat", async (ctx) => {
    const userId = String(ctx.from.id), prefix = String(ctx.match || "").trim();
    if (!prefix) { await safeReply(ctx, `نمونه: ${code("/unblockchat CONVERSATION_ID")}`); return; }
    const matches = await all(env.DB, `SELECT * FROM conversation_blocks WHERE blocker_id=? AND conversation_id LIKE ? LIMIT 2`, userId, `${prefix}%`);
    if (matches.length !== 1) { await safeReply(ctx, "گفتگوی مسدود پیدا نشد یا شناسه مبهم است. از /blocklist شناسه کامل را بردارید."); return; }
    await run(env.DB, `DELETE FROM conversation_blocks WHERE conversation_id=? AND blocker_id=?`, matches[0].conversation_id, userId);
    await audit(env, userId, "conversation_unblocked", matches[0].blocked_id, null, { conversation_id: matches[0].conversation_id });
    await safeReply(ctx, `✅ مسدودی گفتگوی ${code(matches[0].conversation_id)} برداشته شد.`);
  });

  bot.command("admin", async (ctx) => showAdminHome(ctx, env));
  bot.command("users", async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, "⛔ دسترسی مدیریت ندارید."); await showUsers(ctx, env, asPage(ctx.match)); });
  bot.command("user", async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, "⛔ دسترسی مدیریت ندارید."); await showUserAdmin(ctx, env, String(ctx.match || "").trim()); });
  bot.command("history_admin", async (ctx) => {
    if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, "⛔ دسترسی مدیریت ندارید.");
    const parts = String(ctx.match || "").trim().split(/\s+/);
    await showAdminHistory(ctx, env, parts[0], asPage(parts[1]));
  });
  bot.command("recent", async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, "⛔ دسترسی مدیریت ندارید."); await showRecent(ctx, env, asPage(ctx.match)); });
  bot.command("stats", async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, "⛔ دسترسی مدیریت ندارید."); await showAdminStats(ctx, env); });
  bot.command("audit", async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, "⛔ دسترسی مدیریت ندارید."); await showAudit(ctx, env, asPage(ctx.match)); });
  bot.command("errors", async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, "⛔ دسترسی مدیریت ندارید."); await showErrors(ctx, env); });
  bot.command("blocked", async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, "⛔ دسترسی مدیریت ندارید."); await showAdminBlocked(ctx, env, asPage(ctx.match)); });
  bot.command("search", async (ctx) => {
    if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, "⛔ دسترسی مدیریت ندارید.");
    const q = String(ctx.match || "").trim();
    if (q.length < 2) return safeReply(ctx, `عبارت جستجو را وارد کنید؛ نمونه: ${code("/search @username")} یا ${code("/search 123456")}`);
    const id = parseTelegramId(q);
    const term = `%${q}%`;
    const rows = await all(env.DB, `SELECT * FROM users WHERE (? IS NOT NULL AND id=?) OR username=? COLLATE NOCASE OR first_name LIKE ? OR last_name LIKE ? ORDER BY last_seen_at DESC LIMIT 10`,
      id, id || "", q.replace(/^@/, ""), term, term);
    if (!rows.length) return safeReply(ctx, `🔎 کاربری با عبارت ${code(q)} پیدا نشد.`);
    const lines = [`🔎 <b>نتایج جستجو</b> · ${escapeHtml(q)}`], keyboard = [];
    for (const u of rows) {
      lines.push(`\n👤 ${escapeHtml(userName(u))} · ${code(u.id)} · ${usernameText(u)}`);
      keyboard.push([{ text: `👤 ${u.id}`, callback_data: `admin:user:${u.id}` }, { text: "📜 تاریخچه", callback_data: `admin:history:${u.id}` }]);
    }
    await safeReply(ctx, lines.join("\n"), { reply_markup: { inline_keyboard: keyboard } });
  });
  bot.command("block", async (ctx) => {
    if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, `برای مسدودکردن گفتگو از دکمهٔ کنار پیام استفاده کنید؛ فهرست را با ${code("/blocklist")} ببینید.`);
    const target = parseTelegramId(String(ctx.match || "").trim());
    if (!target) return safeReply(ctx, `نمونه: ${code("/block 123456789")}`);
    if (target === String(env.ADMIN_ID)) return safeReply(ctx, "نمی‌توان Owner اصلی را مسدود کرد.");
    await ensureUserStub(env, target);
    await run(env.DB, `UPDATE users SET is_banned=1, updated_at=? WHERE id=?`, NOW(), target);
    await audit(env, ctx.from.id, "user_banned", target);
    await safeReply(ctx, `🚫 کاربر ${code(target)} مسدود شد.`, { reply_markup: { inline_keyboard: [[{ text: "✅ رفع مسدودی", callback_data: `admin:unblock:${target}` }, { text: "👤 پروفایل", callback_data: `admin:user:${target}` }]] } });
  });
  bot.command("unblock", async (ctx) => {
    if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, `برای رفع مسدودی گفتگو از ${code("/unblockchat CONVERSATION_ID")} استفاده کنید.`);
    const target = parseTelegramId(String(ctx.match || "").trim());
    if (!target) return safeReply(ctx, `نمونه: ${code("/unblock 123456789")}`);
    await run(env.DB, `UPDATE users SET is_banned=0, updated_at=? WHERE id=?`, NOW(), target);
    await audit(env, ctx.from.id, "user_unbanned", target);
    await safeReply(ctx, `✅ مسدودی مدیریتی کاربر ${code(target)} برداشته شد.`);
  });
  bot.command("send", async (ctx) => {
    if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, "⛔ دسترسی مدیریت ندارید.");
    const raw = String(ctx.match || "").trim();
    const split = raw.search(/\s/);
    if (split < 1) return safeReply(ctx, `نمونه: ${code("/send USER_ID متن پیام")}`);
    const target = parseTelegramId(raw.slice(0, split));
    const body = raw.slice(split).trim();
    if (!target || !body) return safeReply(ctx, `نمونه: ${code("/send USER_ID متن پیام")}`);
    if (body.length > 3500) return safeReply(ctx, "متن پیام بیشتر از ۳۵۰۰ نویسه است. آن را کوتاه‌تر کنید.");
    if (String(ctx.from.id) === target) return safeReply(ctx, "ارسال پیام مستقیم به خودتان لازم نیست.");
    await ensureUserStub(env, target);
    const conversation = await getOrCreateConversation(env, String(ctx.from.id), target, String(ctx.from.id));
    const data = await addAdminMessage(env, ctx.update.update_id, conversation, String(ctx.from.id), target, body);
    await audit(env, ctx.from.id, "admin_send_queued", target, data.id, { conversation_id: conversation.id });
    await safeReply(ctx, `📤 پیام مدیریت در صف ارسال قرار گرفت.\nشناسه: ${code(`#M${data.id}`)}\nمقصد: ${code(target)}`);
  });
  bot.command("broadcast", async (ctx) => {
    if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, "⛔ دسترسی مدیریت ندارید.");
    const body = String(ctx.match || "").trim();
    if (!body) return safeReply(ctx, `نمونه: ${code("/broadcast متن اطلاعیه")}`);
    if (body.length > 3500) return safeReply(ctx, "متن اطلاعیه بیشتر از ۳۵۰۰ نویسه است. آن را کوتاه‌تر کنید.");
    const now = NOW();
    const ins = await env.DB.prepare(`INSERT INTO broadcast_jobs(created_by,text_content,status,created_at) VALUES(?,?,'queued',?) RETURNING id`).bind(String(ctx.from.id), body, now).first();
    const jobId = Number(ins.id);
    await run(env.DB, `INSERT OR IGNORE INTO broadcast_recipients(job_id,user_id,status,attempts,next_attempt_at)
      SELECT ?, id, 'pending', 0, 0 FROM users WHERE started_at IS NOT NULL AND is_banned=0 AND bot_blocked_at IS NULL`, jobId);
    const recipientCount = Number((await first(env.DB, `SELECT COUNT(*) n FROM broadcast_recipients WHERE job_id=?`, jobId))?.n || 0);
    await audit(env, ctx.from.id, "broadcast_created", null, null, { job_id: jobId, recipients: recipientCount });
    await safeReply(ctx, `📢 <b>ارسال همگانی در صف قرار گرفت</b>\nشناسه عملیات: ${code(`#B${jobId}`)}\nگیرندگان اولیه: <b>${recipientCount}</b>\n${quote("ارسال تدریجی در پس‌زمینه انجام می‌شود تا درخواست وبهوک طولانی نشود.")}`);
  });
  bot.command("addadmin", async (ctx) => {
    if (!(await isOwner(env, ctx.from.id))) return safeReply(ctx, "⛔ فقط Owner می‌تواند مدیر اضافه کند.");
    const target = parseTelegramId(String(ctx.match || "").trim());
    if (!target) return safeReply(ctx, `نمونه: ${code("/addadmin 123456789")}`);
    if (target === String(env.ADMIN_ID)) return safeReply(ctx, "این شناسه Owner اصلی است و از قبل دسترسی دارد.");
    await run(env.DB, `INSERT OR IGNORE INTO admins(user_id,role,created_by,created_at) VALUES(?,'admin',?,?)`, target, String(ctx.from.id), NOW());
    await audit(env, ctx.from.id, "admin_added", target);
    await safeReply(ctx, `✅ دسترسی مدیریت برای ${code(target)} ثبت شد.`);
  });
  bot.command("deladmin", async (ctx) => {
    if (!(await isOwner(env, ctx.from.id))) return safeReply(ctx, "⛔ فقط Owner می‌تواند مدیر حذف کند.");
    const target = parseTelegramId(String(ctx.match || "").trim());
    if (!target) return safeReply(ctx, `نمونه: ${code("/deladmin 123456789")}`);
    if (target === String(env.ADMIN_ID)) return safeReply(ctx, "⛔ Owner اصلی از این مسیر حذف نمی‌شود.");
    await run(env.DB, `DELETE FROM admins WHERE user_id=?`, target);
    await audit(env, ctx.from.id, "admin_deleted", target);
    await safeReply(ctx, `✅ دسترسی مدیریت ${code(target)} حذف شد.`);
  });
  bot.command("maintenance", async (ctx) => {
    if (!(await isOwner(env, ctx.from.id))) return safeReply(ctx, "⛔ فقط Owner می‌تواند حالت تعمیر را تغییر دهد.");
    const value = String(ctx.match || "").trim().toLowerCase();
    if (!["on", "off"].includes(value)) return safeReply(ctx, `نمونه: ${code("/maintenance on")} یا ${code("/maintenance off")}`);
    await setSetting(env, "maintenance", value === "on" ? "1" : "0", ctx.from.id);
    await safeReply(ctx, value === "on" ? "🛠 حالت تعمیر فعال شد؛ دستورات مدیریتی همچنان قابل استفاده‌اند." : "✅ حالت تعمیر غیرفعال شد.");
  });

  bot.command("retry_failed", async (ctx) => {
    if (!(await isAdmin(env, ctx.from.id))) return safeReply(ctx, "⛔ دسترسی مدیریت ندارید.");
    const limit = Math.max(1, Math.min(100, Number.parseInt(String(ctx.match || "25"), 10) || 25));
    await run(env.DB, `UPDATE message_deliveries SET status='pending', attempts=0, next_attempt_at=0, locked_at=NULL, last_error=NULL WHERE status IN ('failed','partial') AND id IN (SELECT id FROM message_deliveries WHERE status IN ('failed','partial') ORDER BY id DESC LIMIT ?)`, limit);
    await run(env.DB, `UPDATE notifications SET status='pending', attempts=0, next_attempt_at=0, locked_at=NULL, last_error=NULL WHERE status='failed' AND id IN (SELECT id FROM notifications WHERE status='failed' ORDER BY id DESC LIMIT ?)`, limit);
    await audit(env, ctx.from.id, "failed_jobs_requeued", null, null, { limit });
    await safeReply(ctx, `🔁 حداکثر ${limit} تحویل/اعلان ناموفق برای تلاش مجدد در صف قرار گرفتند.`);
  });

  bot.on("my_chat_member", async (ctx) => {
    const chatId = ctx.myChatMember?.chat?.id;
    const status = ctx.myChatMember?.new_chat_member?.status;
    if (!chatId || ctx.myChatMember?.chat?.type !== "private") return;
    if (status === "kicked") {
      await run(env.DB, `UPDATE users SET bot_blocked_at=?, updated_at=? WHERE id=?`, NOW(), NOW(), String(chatId));
      await audit(env, ctx.myChatMember.from?.id, "bot_blocked_by_user", String(chatId));
    } else if (status === "member" || status === "administrator") {
      await run(env.DB, `UPDATE users SET bot_blocked_at=NULL, updated_at=? WHERE id=?`, NOW(), String(chatId));
    }
  });

  bot.callbackQuery(/^menu:home$/, async (ctx) => {
    await safeAnswer(ctx);
    await safeEdit(ctx, welcomeText(env, String(ctx.from.id)), { reply_markup: homeKeyboard(await isAdmin(env, ctx.from.id)) });
  });
  bot.callbackQuery(/^menu:link$/, async (ctx) => { await safeAnswer(ctx); await showLink(ctx, env); });
  bot.callbackQuery(/^menu:help$/, async (ctx) => { await safeAnswer(ctx); await safeReply(ctx, helpText(), { reply_markup: { inline_keyboard: [[{ text: "🏠 منو", callback_data: "menu:home" }]] } }); });
  bot.callbackQuery(/^menu:me$/, async (ctx) => { await safeAnswer(ctx); await showUserStats(ctx, env); });
  bot.callbackQuery(/^menu:history:(\d+)$/, async (ctx) => { await safeAnswer(ctx); await showHistory(ctx, env, String(ctx.from.id), asPage(ctx.match[1]), false, false); });
  bot.callbackQuery(/^menu:inbox:(\d+)$/, async (ctx) => { await safeAnswer(ctx); await showHistory(ctx, env, String(ctx.from.id), asPage(ctx.match[1]), false, true); });
  bot.callbackQuery(/^menu:blocklist$/, async (ctx) => { await safeAnswer(ctx); await showBlocklist(ctx, env, String(ctx.from.id)); });

  bot.callbackQuery(/^reply:([A-Za-z0-9_-]{8,40})$/, async (ctx) => {
    const conversationId = ctx.match[1], userId = String(ctx.from.id);
    const conversation = await getConversation(env, conversationId);
    if (!conversation || (conversation.user_a !== userId && conversation.user_b !== userId)) {
      await safeAnswer(ctx, "این گفتگو معتبر نیست یا به شما تعلق ندارد.", { show_alert: true }); return;
    }
    const targetId = otherParticipant(conversation, userId);
    if (await isBlockedBetween(env, conversation.id, targetId, userId)) {
      await safeAnswer(ctx, "طرف مقابل این گفتگو را مسدود کرده است.", { show_alert: true }); return;
    }
    await setActiveConversation(env, userId, conversation.id);
    await audit(env, userId, "conversation_selected", targetId, null, { conversation_id: conversation.id });
    await safeAnswer(ctx, "گفتگو انتخاب شد.");
    await safeReply(ctx, `✍️ <b>گفتگوی فعال انتخاب شد</b>\n${quote("پیام بعدی شما فقط به همین گفتگو ارسال می‌شود؛ برای تغییر مقصد، دکمهٔ پاسخ پیام دیگری را بزنید.")}\n🧵 ${code(conversation.id)}\n🆔 طرف گفتگو برای نمایش ناشناس است.`);
  });
  bot.callbackQuery(/^block:([A-Za-z0-9_-]{8,40})$/, async (ctx) => {
    const conversationId = ctx.match[1], userId = String(ctx.from.id);
    const conv = await getConversation(env, conversationId);
    if (!conv || (conv.user_a !== userId && conv.user_b !== userId)) { await safeAnswer(ctx, "گفتگو معتبر نیست.", { show_alert: true }); return; }
    const other = otherParticipant(conv, userId);
    await run(env.DB, `INSERT OR IGNORE INTO conversation_blocks(conversation_id,blocker_id,blocked_id,created_at) VALUES(?,?,?,?)`, conversationId, userId, other, NOW());
    await audit(env, userId, "conversation_blocked", other, null, { conversation_id: conversationId });
    await safeAnswer(ctx, "گفتگو مسدود شد.");
    await safeReply(ctx, `🚫 این گفتگو مسدود شد. شناسهٔ آن ${code(conversationId)} است. برای مدیریت: ${code("/blocklist")}`);
  });
  bot.callbackQuery(/^unblockchat:([A-Za-z0-9_-]{8,40})$/, async (ctx) => {
    const convId = ctx.match[1], userId = String(ctx.from.id);
    await run(env.DB, `DELETE FROM conversation_blocks WHERE conversation_id=? AND blocker_id=?`, convId, userId);
    await audit(env, userId, "conversation_unblocked", convId);
    await safeAnswer(ctx, "مسدودی برداشته شد.");
    await showBlocklist(ctx, env, userId);
  });
  bot.callbackQuery(/^delboth:(\d+)$/, async (ctx) => { await safeAnswer(ctx); await requestDeleteBoth(ctx, env, ctx.match[1]); });
  bot.callbackQuery(/^delboth_yes:(\d+)$/, async (ctx) => { await executeDeleteBoth(ctx, env, ctx.match[1]); });
  bot.callbackQuery(/^delboth_no:(\d+)$/, async (ctx) => { await safeAnswer(ctx, "حذف لغو شد."); await safeEdit(ctx, `✅ عملیات حذف پیام ${code(`#M${ctx.match[1]}`)} لغو شد.`); });

  bot.callbackQuery(/^admin:home$/, async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); await safeAnswer(ctx); await showAdminHome(ctx, env); });
  bot.callbackQuery(/^admin:users:(\d+)$/, async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); await safeAnswer(ctx); await showUsers(ctx, env, asPage(ctx.match[1])); });
  bot.callbackQuery(/^admin:stats$/, async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); await safeAnswer(ctx); await showAdminStats(ctx, env); });
  bot.callbackQuery(/^admin:user:(\d+)$/, async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); await safeAnswer(ctx); await showUserAdmin(ctx, env, ctx.match[1]); });
  bot.callbackQuery(/^admin:history:(\d+)$/, async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); await safeAnswer(ctx); await showAdminHistory(ctx, env, ctx.match[1], 1); });
  bot.callbackQuery(/^admin:historypage:(\d+):(\d+)$/, async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); await safeAnswer(ctx); await showAdminHistory(ctx, env, ctx.match[1], asPage(ctx.match[2])); });
  bot.callbackQuery(/^admin:recent:(\d+)$/, async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); await safeAnswer(ctx); await showRecent(ctx, env, asPage(ctx.match[1])); });
  bot.callbackQuery(/^admin:audit:(\d+)$/, async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); await safeAnswer(ctx); await showAudit(ctx, env, asPage(ctx.match[1])); });
  bot.callbackQuery(/^admin:errors$/, async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); await safeAnswer(ctx); await showErrors(ctx, env); });
  bot.callbackQuery(/^admin:blocked:(\d+)$/, async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); await safeAnswer(ctx); await showAdminBlocked(ctx, env, asPage(ctx.match[1])); });
  bot.callbackQuery(/^admin:broadcast_help$/, async (ctx) => { if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true }); await safeAnswer(ctx); await safeReply(ctx, `📢 <b>ارسال همگانی</b>\n${quote("متن پیام به کاربران ثبت‌شده‌ای که ربات را بلاک نکرده‌اند در پس‌زمینه ارسال می‌شود.")}\nنمونه: ${code("/broadcast اطلاعیه جدید")}`); });
  bot.callbackQuery(/^admin:reply:(\d+)$/, async (ctx) => {
    if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true });
    const target = ctx.match[1];
    if (String(target) === String(ctx.from.id)) return safeAnswer(ctx, "نمی‌توانید به خودتان پاسخ بدهید.", { show_alert: true });
    await ensureUserStub(env, target);
    const conv = await getOrCreateConversation(env, String(ctx.from.id), target, String(ctx.from.id));
    await setActiveConversation(env, ctx.from.id, conv.id);
    await audit(env, ctx.from.id, "admin_reply_target_selected", target, null, { conversation_id: conv.id });
    await safeAnswer(ctx, "مقصد پاسخ انتخاب شد.");
    await safeReply(ctx, `✍️ <b>پاسخ مستقیم مدیریت</b>\nمقصد: ${code(target)}\n${quote("پیام بعدی شما به‌عنوان پیام مدیریت ارسال می‌شود. برای لغو /cancel را بفرستید.")}`);
  });
  bot.callbackQuery(/^admin:block:(\d+)$/, async (ctx) => {
    if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true });
    const target = ctx.match[1];
    if (String(target) === String(env.ADMIN_ID)) return safeAnswer(ctx, "Owner اصلی قابل مسدودسازی نیست.", { show_alert: true });
    await ensureUserStub(env, target);
    await run(env.DB, `UPDATE users SET is_banned=1, updated_at=? WHERE id=?`, NOW(), target);
    await audit(env, ctx.from.id, "user_banned", target);
    await safeAnswer(ctx, "کاربر مسدود شد.");
    await safeReply(ctx, `🚫 کاربر ${code(target)} مسدود شد.`, { reply_markup: { inline_keyboard: [[{ text: "✅ رفع مسدودی", callback_data: `admin:unblock:${target}` }]] } });
  });
  bot.callbackQuery(/^admin:unblock:(\d+)$/, async (ctx) => {
    if (!(await isAdmin(env, ctx.from.id))) return safeAnswer(ctx, "دسترسی مدیریت ندارید.", { show_alert: true });
    const target = ctx.match[1];
    await run(env.DB, `UPDATE users SET is_banned=0, updated_at=? WHERE id=?`, NOW(), target);
    await audit(env, ctx.from.id, "user_unbanned", target);
    await safeAnswer(ctx, "مسدودی مدیریتی برداشته شد.");
    await showUserAdmin(ctx, env, target);
  });

  bot.on("message", async (ctx) => recordIncoming(ctx, env));
  return bot;
}

function getRuntime(env) {
  if (!cachedRuntime || cachedRuntime.token !== env.BOT_TOKEN || cachedRuntime.db !== env.DB) {
    const bot = new Bot(env.BOT_TOKEN, { client: { timeoutSeconds: 8 } });
    cachedRuntime = { token: env.BOT_TOKEN, db: env.DB, bot, setupPromise: setupHandlers(bot, env), initPromise: null };
  }
  return cachedRuntime;
}
async function initializedBot(env) {
  const runtime = getRuntime(env);
  await runtime.setupPromise;
  runtime.initPromise ||= runtime.bot.init();
  await runtime.initPromise;
  return runtime.bot;
}
async function claimRow(env, table) {
  const now = nowMs();
  const stale = now - 2 * 60 * 1000;
  const allowedTables = new Set(["webhook_updates", "message_deliveries", "notifications", "broadcast_recipients", "delete_jobs"]);
  if (!allowedTables.has(table)) throw new Error("Invalid queue table");
  const idColumn = table === "webhook_updates" ? "update_id" : "id";
  const orderBy = table === "webhook_updates" ? "candidate.received_at ASC, candidate.update_id ASC" : "candidate.id ASC";
  const eligible = (alias) => `((${alias}.status IN ('pending','retry') AND ${alias}.next_attempt_at<=?) OR (${alias}.status='processing' AND ${alias}.locked_at IS NOT NULL AND ${alias}.locked_at<?))`;
  let orderingGuard = "";
  if (table === "webhook_updates") {
    // A retriable Update must not freeze the entire bot. Preserve order for each actor,
    // while letting updates from unrelated Telegram users continue.
    const actor = (alias) => `COALESCE(
      json_extract(${alias}.payload_json, '$.message.from.id'),
      json_extract(${alias}.payload_json, '$.callback_query.from.id'),
      json_extract(${alias}.payload_json, '$.my_chat_member.chat.id'),
      json_extract(${alias}.payload_json, '$.my_chat_member.from.id')
    )`;
    orderingGuard = `AND NOT EXISTS (
      SELECT 1 FROM webhook_updates prior
      WHERE prior.update_id < candidate.update_id
        AND prior.status IN ('pending','retry','processing')
        AND ${actor('prior')} IS ${actor('candidate')}
    )`;
  } else {
    // Preserve FIFO per recipient/chat, not globally. A user with a transient API
    // failure must not delay deliveries, notifications, or deletions for everyone.
    const keyColumn = ({ message_deliveries: "recipient_id", notifications: "recipient_id", broadcast_recipients: "user_id", delete_jobs: "chat_id" })[table];
    orderingGuard = `AND NOT EXISTS (
      SELECT 1 FROM ${table} prior
      WHERE prior.id < candidate.id
        AND prior.${keyColumn} = candidate.${keyColumn}
        AND prior.status IN ('pending','retry','processing')
    )`;
  }
  return first(env.DB, `UPDATE ${table}
    SET status='processing', attempts=attempts+1, locked_at=?
    WHERE ${idColumn}=(
      SELECT candidate.${idColumn} FROM ${table} candidate
      WHERE ${eligible('candidate')}
      ${orderingGuard}
      ORDER BY ${orderBy} LIMIT 1
    )
    RETURNING *`, now, now, stale);
}
async function acquireDrainLock(env) {
  const token = randomId(24), now = nowMs();
  const row = await first(env.DB, `INSERT INTO worker_locks(lock_name,lock_token,expires_at)
    VALUES('drain',?,?)
    ON CONFLICT(lock_name) DO UPDATE SET lock_token=excluded.lock_token, expires_at=excluded.expires_at
    WHERE worker_locks.expires_at<=?
    RETURNING lock_token`, token, now + 90000, now);
  return row?.lock_token === token ? token : null;
}
async function renewDrainLock(env, token) {
  if (!token) return;
  await run(env.DB, `UPDATE worker_locks SET expires_at=? WHERE lock_name='drain' AND lock_token=?`, nowMs() + 90000, token);
}
async function releaseDrainLock(env, token) {
  if (!token) return;
  await run(env.DB, `UPDATE worker_locks SET expires_at=0 WHERE lock_name='drain' AND lock_token=?`, token);
}
async function updateQueueFailure(env, table, idColumn, idValue, attempts, error, maxAttempts, options = {}) {
  const text = telegramErrorText(error);
  const codeValue = telegramErrorCode(error);
  const blocked = codeValue === 403;
  const final = blocked || !isRetryable(error) || attempts >= maxAttempts;
  const status = blocked ? "blocked" : final ? "failed" : "pending";
  const delay = retryDelay(attempts, error);
  await run(env.DB, `UPDATE ${table} SET status=?, next_attempt_at=?, locked_at=NULL, last_error=? WHERE ${idColumn}=?`,
    status, final ? 0 : nowMs() + delay, text, idValue);
  if (blocked && options.recipientId) await markBlocked(env, options.recipientId, text);
  return { final, blocked, status, text, retryAt: nowMs() + delay };
}
async function processPendingUpdates(env, bot, limit = 12, lockToken = null) {
  for (let i = 0; i < limit; i++) {
    await renewDrainLock(env, lockToken);
    const row = await claimRow(env, "webhook_updates");
    if (!row) break;
    try {
      const update = JSON.parse(row.payload_json);
      await bot.handleUpdate(update);
      await run(env.DB, `UPDATE webhook_updates SET status='done', processed_at=?, locked_at=NULL, last_error=NULL WHERE update_id=?`, NOW(), row.update_id);
    } catch (error) {
      await logError(env, "process_update", error, row.update_id);
      const result = await updateQueueFailure(env, "webhook_updates", "update_id", row.update_id, Number(row.attempts), error, MAX_UPDATE_ATTEMPTS);
      if (result.final) {
        await enqueueNotification(env, `failed-update-alert:${row.update_id}`, env.ADMIN_ID,
          `🚨 <b>پردازش یک Update ناموفق شد</b>\nشناسه Update: ${code(row.update_id)}\n${quote(result.text)}\n🧾 تلاش: ${code(row.attempts)}`);
        await audit(env, null, "update_permanently_failed", String(row.update_id), null, { error: result.text });
      }
    }
  }
}
function deliveryHeader(env, row, recipientId, isAdminRecipient = String(recipientId) === String(env.ADMIN_ID)) {
  const time = dateText(row.created_at, env);
  if (isAdminRecipient) {
    return `📨 <b>گزارش پیام در ربات</b>\n${quote("محتوای پیام در پیام جداگانه زیر نمایش داده شده است.")}\n🆔 شناسه پیام: ${code(`#M${row.message_id}`)}\n👤 فرستنده: ${code(row.sender_id)}${row.sender_username ? ` · @${escapeHtml(row.sender_username)}` : ""}\n🎯 گیرنده: ${code(row.recipient_id)}\n🧵 گفتگو: ${code(row.conversation_id)}\n📦 نوع: ${escapeHtml(typeFa(row.message_type))}\n🕒 ${code(time)}`;
  }
  if (row.is_admin_message) {
    return `👑 <b>پیام مدیریت ربات</b>\n${quote("این پیام به‌صورت مستقیم از مدیریت ربات ارسال شده است.")}\n🆔 شناسه پیام: ${code(`#M${row.message_id}`)}\n🕒 ${code(time)}`;
  }
  return `📩 <b>پیام ناشناس جدید</b>\n${quote("هویت فرستنده برای شما مخفی است. برای پاسخ، دکمهٔ زیر را بزنید.")}\n🆔 شناسه پیام: ${code(`#M${row.message_id}`)}\n📦 نوع: ${escapeHtml(typeFa(row.message_type))}\n🕒 ${code(time)}`;
}
function deliveryKeyboard(env, row, recipientId, isAdminRecipient = String(recipientId) === String(env.ADMIN_ID)) {
  if (isAdminRecipient) {
    return { inline_keyboard: [
      [{ text: "↩️ پاسخ مستقیم به فرستنده", callback_data: `admin:reply:${row.sender_id}` }],
      [{ text: "👤 پروفایل فرستنده", callback_data: `admin:user:${row.sender_id}` }, { text: "📜 تاریخچه", callback_data: `admin:history:${row.sender_id}` }],
      [{ text: "🚫 مسدودسازی کاربر", callback_data: `admin:block:${row.sender_id}` }]
    ] };
  }
  return { inline_keyboard: [
    [{ text: "↩️ پاسخ به این گفتگو", callback_data: `reply:${row.conversation_id}` }],
    [{ text: "🚫 مسدودکردن گفتگو", callback_data: `block:${row.conversation_id}` }, { text: `🗑 حذف #M${row.message_id} دوطرفه`, callback_data: `delboth:${row.message_id}` }]
  ] };
}
async function processOneDelivery(env, bot, lockToken = null) {
  await renewDrainLock(env, lockToken);
  const claimed = await claimRow(env, "message_deliveries");
  if (!claimed) return false;
  const row = await first(env.DB, `SELECT d.*, m.conversation_id, m.sender_id, m.recipient_id, m.source_chat_id,
      m.source_message_id, m.message_type, m.text_content, m.caption, m.is_admin_message, m.created_at AS message_created_at,
      m.deleted_for_both_at, s.username AS sender_username, s.first_name AS sender_first_name
    FROM message_deliveries d JOIN messages m ON m.id=d.message_id
    LEFT JOIN users s ON s.id=m.sender_id WHERE d.id=?`, claimed.id);
  if (!row) {
    await run(env.DB, `UPDATE message_deliveries SET status='failed', last_error='message record missing', locked_at=NULL WHERE id=?`, claimed.id);
    return true;
  }
  if (row.deleted_for_both_at) {
    await run(env.DB, `UPDATE message_deliveries SET status='cancelled', locked_at=NULL, last_error='message deleted for both' WHERE id=?`, row.id);
    return true;
  }
  const recipient = await getUser(env, row.recipient_id);
  if (!recipient || !recipient.started_at) {
    await run(env.DB, `UPDATE message_deliveries SET status='failed', locked_at=NULL, last_error='recipient has not started the bot' WHERE id=?`, row.id);
    await enqueueNotification(env, `delivery-failed:${row.id}`, row.sender_id,
      `⚠️ <b>پیام تحویل نشد</b>\nشناسه: ${code(`#M${row.message_id}`)}\n${quote("مقصد هنوز ربات را Start نکرده است؛ او باید ابتدا ربات را باز کند.")}`);
    await enqueueNotification(env, `delivery-failed-admin:${row.id}`, env.ADMIN_ID,
      `⚠️ <b>تحویل پیام ناموفق شد</b>\nشناسه پیام: ${code(`#M${row.message_id}`)}\nفرستنده: ${code(row.sender_id)} · گیرنده: ${code(row.recipient_id)}\n${quote("مقصد در دیتابیس ثبت است اما ربات را شروع نکرده است.")}`);
    return true;
  }
  if (recipient?.is_banned) {
    await run(env.DB, `UPDATE message_deliveries SET status='blocked', locked_at=NULL, last_error='recipient is admin-banned' WHERE id=?`, row.id);
    await enqueueNotification(env, `delivery-failed:${row.id}`, row.sender_id,
      `⚠️ <b>پیام تحویل نشد</b>\nشناسه: ${code(`#M${row.message_id}`)}\n${quote("مقصد فعلاً در ربات مسدود است.")}`);
    return true;
  }
  if (recipient?.bot_blocked_at) {
    await run(env.DB, `UPDATE message_deliveries SET status='blocked', locked_at=NULL, last_error='recipient has blocked bot' WHERE id=?`, row.id);
    await enqueueNotification(env, `delivery-failed:${row.id}`, row.sender_id,
      `⚠️ <b>پیام تحویل نشد</b>\nشناسه: ${code(`#M${row.message_id}`)}\n${quote("مخاطب ربات را مسدود کرده یا دسترسی خصوصی او بسته است. پیام در صف نامحدود نگه داشته نمی‌شود.")}`);
    return true;
  }
  if (await isBlockedBetween(env, row.conversation_id, row.recipient_id, row.sender_id)) {
    await run(env.DB, `UPDATE message_deliveries SET status='blocked', locked_at=NULL, last_error='recipient blocked conversation' WHERE id=?`, row.id);
    await enqueueNotification(env, `delivery-failed:${row.id}`, row.sender_id,
      `⛔ <b>پیام تحویل نشد</b>\nشناسه: ${code(`#M${row.message_id}`)}\n${quote("طرف مقابل دریافت پیام از این گفتگو را مسدود کرده است.")}`);
    return true;
  }
  try {
    const adminRecipient = await isAdmin(env, row.recipient_id);
    if (!row.header_message_id) {
      const header = await bot.api.sendMessage(Number(row.recipient_id), deliveryHeader(env, { ...row, created_at: row.message_created_at }, row.recipient_id, adminRecipient), {
        parse_mode: "HTML", reply_markup: deliveryKeyboard(env, row, row.recipient_id, adminRecipient), link_preview_options: { is_disabled: true }
      });
      await run(env.DB, `UPDATE message_deliveries SET header_message_id=?, status='processing', locked_at=? WHERE id=?`, header.message_id, nowMs(), row.id);
      row.header_message_id = header.message_id;
    }
    if (!row.content_message_id) {
      let copied;
      if (row.source_chat_id && row.source_message_id) {
        copied = await bot.api.copyMessage(Number(row.recipient_id), Number(row.source_chat_id), Number(row.source_message_id));
        await run(env.DB, `UPDATE message_deliveries SET content_message_id=?, status='processing', locked_at=? WHERE id=?`, copied.message_id, nowMs(), row.id);
        row.content_message_id = copied.message_id;
      } else {
        const body = String(row.text_content || row.caption || "").slice(0, 3500);
        copied = await bot.api.sendMessage(Number(row.recipient_id), `${quote(body || "پیام متنی")}`, { parse_mode: "HTML", link_preview_options: { is_disabled: true } });
        await run(env.DB, `UPDATE message_deliveries SET content_message_id=?, status='processing', locked_at=? WHERE id=?`, copied.message_id, nowMs(), row.id);
        row.content_message_id = copied.message_id;
      }
    }
    await run(env.DB, `UPDATE message_deliveries SET status='sent', sent_at=?, locked_at=NULL, last_error=NULL WHERE id=?`, NOW(), row.id);
    await enqueueNotification(env, `delivery-confirm:${row.id}`, row.sender_id,
      `✅ <b>پیام تحویل شد</b>\nشناسه: ${code(`#M${row.message_id}`)}\n🕒 ${code(dateText(NOW(), env))}`);
    await audit(env, null, "message_delivered", row.recipient_id, row.message_id, { delivery_id: row.id });
  } catch (error) {
    await logError(env, "deliver_message", error, row.message_id);
    const result = await updateQueueFailure(env, "message_deliveries", "id", row.id, Number(claimed.attempts), error, MAX_DELIVERY_ATTEMPTS, { recipientId: row.recipient_id });
    if (result.final) {
      if (row.header_message_id) {
        try {
          await bot.api.editMessageText(Number(row.recipient_id), Number(row.header_message_id),
            `⚠️ <b>تحویل پیام ناموفق بود</b>\nشناسه: ${code(`#M${row.message_id}`)}\n${quote("محتوا قابل ارسال نبود یا مقصد دسترسی به ربات ندارد.")}`, { parse_mode: "HTML", reply_markup: { inline_keyboard: [] } });
        } catch { /* best effort */ }
      }
      await enqueueNotification(env, `delivery-failed:${row.id}`, row.sender_id,
        `⚠️ <b>پیام تحویل نشد</b>\nشناسه: ${code(`#M${row.message_id}`)}\n${quote(result.text)}`);
      await enqueueNotification(env, `delivery-failed-admin:${row.id}`, env.ADMIN_ID,
        `⚠️ <b>تحویل پیام ناموفق شد</b>\nشناسه پیام: ${code(`#M${row.message_id}`)}\nفرستنده: ${code(row.sender_id)} · گیرنده: ${code(row.recipient_id)}\n${quote(result.text)}`);
      await audit(env, null, "message_delivery_failed", row.recipient_id, row.message_id, { error: result.text, status: result.status });
    }
  }
  return true;
}
async function processDeliveries(env, bot, limit = 12, lockToken = null) {
  for (let i = 0; i < limit; i++) {
    await renewDrainLock(env, lockToken);
    const had = await processOneDelivery(env, bot, lockToken);
    if (!had) break;
  }
}
async function processNotifications(env, bot, limit = 12, lockToken = null) {
  for (let i = 0; i < limit; i++) {
    await renewDrainLock(env, lockToken);
    const row = await claimRow(env, "notifications");
    if (!row) break;
    try {
      const options = { parse_mode: "HTML", link_preview_options: { is_disabled: true } };
      if (row.reply_markup_json) options.reply_markup = JSON.parse(row.reply_markup_json);
      const sent = await bot.api.sendMessage(Number(row.recipient_id), String(row.text_html).slice(0, 3900), options);
      await run(env.DB, `UPDATE notifications SET status='sent', sent_at=?, locked_at=NULL, last_error=NULL WHERE id=?`, NOW(), row.id);
    } catch (error) {
      await logError(env, "send_notification", error, row.id);
      const result = await updateQueueFailure(env, "notifications", "id", row.id, Number(row.attempts), error, MAX_NOTIFICATION_ATTEMPTS, { recipientId: row.recipient_id });
      if (result.final) await audit(env, null, "notification_failed", row.recipient_id, null, { notification_id: row.id, error: result.text });
    }
  }
}
async function processBroadcasts(env, bot, limit = 12, lockToken = null) {
  for (let i = 0; i < limit; i++) {
    await renewDrainLock(env, lockToken);
    const row = await claimRow(env, "broadcast_recipients");
    if (!row) break;
    const job = await first(env.DB, `SELECT * FROM broadcast_jobs WHERE id=?`, row.job_id);
    if (!job) {
      await run(env.DB, `UPDATE broadcast_recipients SET status='failed', locked_at=NULL, last_error='broadcast job missing' WHERE id=?`, row.id);
      continue;
    }
    try {
      await bot.api.sendMessage(Number(row.user_id), `📢 <b>پیام همگانی مدیریت</b>\n${quote(job.text_content)}\n🧾 شناسه ارسال: ${code(`#B${job.id}`)}`, { parse_mode: "HTML", link_preview_options: { is_disabled: true } });
      await run(env.DB, `UPDATE broadcast_recipients SET status='sent', sent_at=?, locked_at=NULL, last_error=NULL WHERE id=?`, NOW(), row.id);
      await run(env.DB, `UPDATE broadcast_jobs SET sent_count=sent_count+1 WHERE id=?`, job.id);
    } catch (error) {
      await logError(env, "broadcast_delivery", error, row.id);
      const result = await updateQueueFailure(env, "broadcast_recipients", "id", row.id, Number(row.attempts), error, 5, { recipientId: row.user_id });
      if (result.final) await run(env.DB, `UPDATE broadcast_jobs SET failed_count=failed_count+1 WHERE id=?`, job.id);
    }
    const remaining = Number((await first(env.DB, `SELECT COUNT(*) n FROM broadcast_recipients WHERE job_id=? AND status IN ('pending','processing')`, job.id))?.n || 0);
    if (remaining === 0) await run(env.DB, `UPDATE broadcast_jobs SET status='finished', finished_at=? WHERE id=? AND status<>'finished'`, NOW(), job.id);
  }
}
async function processDeleteJobs(env, bot, limit = 12, lockToken = null) {
  for (let i = 0; i < limit; i++) {
    await renewDrainLock(env, lockToken);
    const row = await claimRow(env, "delete_jobs");
    if (!row) break;
    try {
      await bot.api.deleteMessage(Number(row.chat_id), Number(row.telegram_message_id));
      await run(env.DB, `UPDATE delete_jobs SET status='sent', locked_at=NULL, last_error=NULL WHERE id=?`, row.id);
    } catch (error) {
      const result = await updateQueueFailure(env, "delete_jobs", "id", row.id, Number(row.attempts), error, 3, { recipientId: row.chat_id });
      // Telegram message-not-found/too-old errors are permanent; preserve the reason in audit.
      if (result.final) await audit(env, null, "telegram_message_delete_failed", row.chat_id, row.message_id, { telegram_message_id: row.telegram_message_id, error: result.text });
    }
  }
}
async function drainQueues(env, options = {}) {
  const lockToken = await acquireDrainLock(env);
  if (!lockToken) return; // Another isolate is already draining; cron will pick up any remainder.
  try {
    const bot = await initializedBot(env);
    const updateLimit = options.updates ?? 12;
    await processPendingUpdates(env, bot, updateLimit, lockToken);
    await processDeliveries(env, bot, options.deliveries ?? 12, lockToken);
    await processNotifications(env, bot, options.notifications ?? 12, lockToken);
    await processDeleteJobs(env, bot, options.deletes ?? 6, lockToken);
    await processBroadcasts(env, bot, options.broadcasts ?? 5, lockToken);
  } finally {
    await releaseDrainLock(env, lockToken);
  }
}
async function adminWebhookAuth(request, env) {
  const auth = request.headers.get("authorization") || "";
  const key = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  return safeEqual(key, env.WEBHOOK_SECRET);
}
async function registerWebhook(request, env, url) {
  if (!(await adminWebhookAuth(request, env))) return jsonResponse({ ok: false, error: "Unauthorized. Use Authorization: Bearer WEBHOOK_SECRET." }, 401);
  const parsed = new URL(request.url);
  const dropPending = parsed.searchParams.get("drop_pending") === "1";
  const webhookUrl = `${url.origin}/webhook`;
  const response = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/setWebhook`, {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify({ url: webhookUrl, secret_token: env.WEBHOOK_SECRET,
      allowed_updates: ["message", "callback_query", "my_chat_member"], drop_pending_updates: dropPending })
  });
  const body = await response.json();
  if (!response.ok || !body.ok) return jsonResponse({ ok: false, telegram: body }, 502);
  try {
    await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/setMyCommands`, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ commands: [
        { command: "start", description: "شروع ربات" }, { command: "link", description: "دریافت لینک ناشناس" },
        { command: "inbox", description: "پیام‌های دریافتی" }, { command: "history", description: "تاریخچه پیام‌ها" },
        { command: "me", description: "پروفایل و آمار من" }, { command: "clearhistory", description: "پاک‌سازی نمای تاریخچه" },
        { command: "blocklist", description: "فهرست گفتگوهای مسدود" }, { command: "help", description: "راهنما" },
        { command: "admin", description: "پنل مدیریت (ادمین)" }
      ] })
    });
  } catch (error) { console.warn("Setting Telegram command list failed", error); }
  return jsonResponse({ ok: true, webhook_url: webhookUrl, drop_pending_updates: dropPending, telegram: body });
}
async function unregisterWebhook(request, env) {
  if (!(await adminWebhookAuth(request, env))) return jsonResponse({ ok: false, error: "Unauthorized. Use Authorization: Bearer WEBHOOK_SECRET." }, 401);
  const response = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/deleteWebhook`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ drop_pending_updates: false })
  });
  const body = await response.json();
  return jsonResponse({ ok: Boolean(response.ok && body.ok), telegram: body }, response.ok && body.ok ? 200 : 502);
}
async function health(env) {
  try {
    await first(env.DB, "SELECT 1 AS ok");
    const counts = await first(env.DB, `SELECT
      (SELECT COUNT(*) FROM webhook_updates WHERE status IN ('pending','processing')) pending_updates,
      (SELECT COUNT(*) FROM message_deliveries WHERE status IN ('pending','processing')) pending_deliveries,
      (SELECT COUNT(*) FROM notifications WHERE status IN ('pending','processing')) pending_notifications,
      (SELECT COUNT(*) FROM broadcast_recipients WHERE status IN ('pending','processing')) pending_broadcasts`);
    return jsonResponse({ ok: true, version: VERSION, database: "connected", queue: counts, time: NOW() });
  } catch (error) {
    return jsonResponse({ ok: false, version: VERSION, database: "error", error: telegramErrorText(error) }, 503);
  }
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    try {
      requireEnv(env);
      if (url.pathname === "/health" && request.method === "GET") return await health(env);
      if (url.pathname === "/" && request.method === "GET") {
        return jsonResponse({ ok: true, service: env.BOT_TITLE || "Anonymous Chat Bot", version: VERSION, endpoints: ["/health", "/webhook"] });
      }
      if (url.pathname === "/register" && request.method === "POST") return await registerWebhook(request, env, url);
      if (url.pathname === "/unregister" && request.method === "POST") return await unregisterWebhook(request, env);
      if (url.pathname === "/webhook") {
        if (request.method !== "POST") return new Response("Method Not Allowed", { status: 405, headers: { allow: "POST" } });
        const secretHeader = request.headers.get("x-telegram-bot-api-secret-token") || "";
        if (!safeEqual(secretHeader, env.WEBHOOK_SECRET)) return new Response("Unauthorized", { status: 401 });
        let update;
        try { update = await request.json(); }
        catch { return new Response("Invalid JSON", { status: 400 }); }
        if (!Number.isSafeInteger(Number(update?.update_id))) return new Response("Invalid update_id", { status: 400 });
        await run(env.DB, `INSERT OR IGNORE INTO webhook_updates(update_id,payload_json,status,attempts,next_attempt_at,received_at)
          VALUES(?,?,'pending',0,0,?)`, Number(update.update_id), JSON.stringify(update), NOW());
        // ACK immediately after the durable D1 write; background + cron drain the durable queue.
        ctx.waitUntil(drainQueues(env, { updates: 8, deliveries: 8, notifications: 8, deletes: 4, broadcasts: 3 }).catch(error => logError(env, "webhook_waitUntil", error, update.update_id)));
        return new Response("OK", { status: 200, headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store" } });
      }
      return jsonResponse({ ok: false, error: "Not found" }, 404);
    } catch (error) {
      await logError(env, "fetch", error);
      return jsonResponse({ ok: false, error: telegramErrorText(error), version: VERSION }, 500);
    }
  },
  async scheduled(_controller, env, ctx) {
    try {
      requireEnv(env);
      await drainQueues(env, { updates: 30, deliveries: 12, notifications: 12, deletes: 8, broadcasts: 8 });
    } catch (error) {
      await logError(env, "scheduled", error);
      throw error;
    }
  }
};
