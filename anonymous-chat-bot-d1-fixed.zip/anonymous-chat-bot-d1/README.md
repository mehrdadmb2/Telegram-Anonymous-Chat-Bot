# ربات چت ناشناس تلگرام — نسخه 5.0.0 (Cloudflare Workers + D1)


> **رفع خطای `Could not resolve "grammy/web"`:** ابتدا در پوشه‌ای که همین `package.json` قرار دارد `npm install` را اجرا کنید و صبر کنید تا کامل شود؛ بعد `npm run check` و `npm run deploy` را اجرا کنید. `node --check` فقط syntax را می‌سنجد و نصب پکیج را انجام نمی‌دهد. مسیر `grammy/web` یک export رسمی از پکیج grammY است؛ بنابراین خطای resolve معمولاً یعنی dependency محلی نصب نشده یا نصب کامل نشده است.

> فایل `wrangler.toml` در این بسته از قبل با D1 ساخته‌شدهٔ شما تنظیم شده است: `anonymous_chat_db_v5` با ID ثبت‌شده در خروجی Wrangler. اگر دیتابیس را دوباره ساختید، حتماً ID جدید را جایگزین کنید.

این نسخه برای Deploy با **Wrangler** ساخته شده است. چون در کد از `grammy/web` استفاده می‌شود، باید Wrangler کتابخانه را هنگام Build بسته‌بندی کند. **کد `src/index.js` را مستقیماً در Dashboard → Edit Code Paste نکنید**؛ آن روش dependencyهای npm را نصب و bundle نمی‌کند و دوباره خطای `No such module "grammy/web"` می‌دهد.

این نسخه به KV قبلی وابسته نیست. برای جلوگیری از تداخل با هر دیتابیس آزمایشی قبلی، از یک D1 تازه با نام `anonymous_chat_db_v5` استفاده کنید. هیچ داده‌ای از KV قدیمی خوانده یا منتقل نمی‌شود.

## قابلیت‌های اصلی

- مسیر ارسال دقیق `sender → conversation → recipient`؛ پیام به تمام افراد قبلی پخش نمی‌شود.
- گفتگوی مستقل با شناسهٔ ثابت و انتخاب پاسخ از دکمهٔ «پاسخ به این گفتگو»؛ دکمه، مقصد را به‌صورت صریح انتخاب می‌کند.
- ثبت پایدار Telegram Update در D1 و پاسخ سریع `200 OK` به webhook، سپس پردازش پس‌زمینه و Cron Trigger هر دقیقه برای Retry صف‌های مانده.
- جلوگیری از ثبت تکراری Update و جلوگیری از تغییر مقصد هنگام Retry.
- صف تحویل پیام و ثبت شناسهٔ پیام تلگرام در سمت گیرنده؛ خطای 403، بلاک‌بودن ربات، کاربر شروع‌نکرده و خطاهای دائمی باعث Retry بی‌نهایت نمی‌شوند.
- پشتیبانی از متن، عکس، ویدئو، GIF/Animation، فایل، صوت، Voice، Video Note، استیکر، مخاطب، مکان و دیگر پیام‌هایی که Telegram API اجازهٔ Copy آن‌ها را بدهد.
- تاریخچه و صندوق ورودی با شناسه‌هایی مثل `#M123` برای هر دو نقش؛ هویت و شناسهٔ Telegram طرف مقابل برای کاربران عادی فاش نمی‌شود، اما مدیر در گزارش مدیریتی شناسهٔ هر دو طرف را می‌بیند.
- پیام‌های خروجی رابط با HTML رسمی Telegram Bot API، شامل `<b>`, `<i>`, `<u>`, `<s>`, `<code>`، `<pre>` و `<blockquote>`. محتوای کاربر پیش از استفاده در قالب HTML escape می‌شود. متن و رسانهٔ اصلی نیز با `copyMessage` کپی می‌شود تا فرمت اصلی فرستنده حفظ شود.
- `clearhistory` فقط تاریخچه را از نمای همان کاربر پنهان می‌کند. `deleteboth` متن را از دیتابیس ربات حذف می‌کند و برای حذف پیام اصلی و کپی‌های ربات از Telegram هم تلاش می‌کند؛ محدودیت‌های خود Telegram ممکن است حذف واقعی بعضی پیام‌ها را ناممکن کند.
- وقتی کاربر ربات را بلاک کند یا چت او قابل دسترسی نباشد، وضعیت در D1 ثبت می‌شود و تحویل به‌عنوان ناموفق/مسدود خاتمه می‌یابد؛ صف بی‌نهایت انباشته نمی‌شود.
- گزارش کامل ادمین، شناسه و پروفایل کاربران، لینک شخصی، تاریخچه، جستجو، آمار، Audit log، خطاها، بلاک مدیریتی، چند مدیر، نگهداری (maintenance)، ارسال مستقیم و Broadcast زمان‌بندی‌شده.

## وضعیت اعتبارسنجی

Syntax، فایل migration و SQL صف به‌صورت محلی بررسی شده‌اند. هنوز build نهایی Wrangler و ارتباط زنده با Telegram در حساب Cloudflare شما اجرا نشده است؛ قبل از استفاده عمومی، گزارش [VALIDATION.md](VALIDATION.md) و چک‌لیست [TESTING.md](TESTING.md) را ببینید.

## فایل‌ها

```text
anonymous-chat-bot-d1/
├── src/index.js                 # منطق Worker و grammY
├── migrations/0001_initial.sql  # دیتابیس تازه D1
├── wrangler.toml                # نام Worker، binding دیتابیس، Cron
├── package.json                 # grammY و Wrangler
├── .dev.vars.example            # نمونهٔ secretهای توسعهٔ محلی
└── scripts/register-webhook.ps1 # ثبت امن webhook از PowerShell
```

## راهنمای نصب روی Windows با Wrangler

### 1. پیش‌نیازها

Node.js نسخهٔ LTS جدید، npm و حساب Cloudflare لازم است. ZIP را Extract کنید و PowerShell را در پوشه‌ای باز کنید که `package.json` داخل آن است.

```powershell
npm install
npx wrangler login
npx wrangler whoami
```

اگر `npm install` به‌دلیل شبکه با `ECONNRESET` شکست خورد، این یک خطای دریافت پکیج است نه خطای Bot. اتصال به `registry.npmjs.org` را بررسی کنید و بعد دوباره `npm install` را اجرا کنید.

### 2. ساخت D1 تازه

```powershell
npx wrangler d1 create anonymous_chat_db_v5
```

خروجی یک `database_id` می‌دهد. فایل `wrangler.toml` را باز کنید و این مقدار را جایگزین کنید:

```toml
database_name = "anonymous_chat_db_v5"
database_id = "REPLACE_WITH_D1_DATABASE_ID"
```

مقدار واقعی باید UUID/ID بازگشتی Cloudflare باشد. مقدار `DB` را تغییر ندهید؛ کد به `env.DB` وابسته است.

### 3. ساخت جدول‌های دیتابیس

```powershell
npx wrangler d1 migrations apply anonymous_chat_db_v5 --remote
```

اگر موفق باشد، migration `0001_initial.sql` در دیتابیس جدید اجرا می‌شود. اگر این D1 قبلاً برای نسخهٔ دیگری استفاده شده، یک نام کاملاً تازه بسازید و همان ID تازه را در `wrangler.toml` بگذارید؛ migration را روی یک دیتابیس قدیمی با جدول‌های متفاوت اجرا نکنید.

### 4. تنظیم Secrets

سه دستور زیر را جداگانه اجرا کنید؛ Wrangler هنگام اجرای هرکدام از شما مقدار را می‌پرسد:

```powershell
npx wrangler secret put BOT_TOKEN
npx wrangler secret put ADMIN_ID
npx wrangler secret put WEBHOOK_SECRET
```

مقادیر:

- `BOT_TOKEN`: توکن واقعی BotFather برای `@NashnasiChatBot`.
- `ADMIN_ID`: مقدار دقیق `381200758`.
- `WEBHOOK_SECRET`: یک رشتهٔ تصادفی مخصوص همین Worker، فقط با حروف انگلیسی، عدد، `_` یا `-` و طول ۱ تا ۲۵۶ کاراکتر.

برای ساخت یک مقدار تصادفی ۶۴ رقمی در PowerShell:

```powershell
$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
$bytes = New-Object byte[] 32
$rng.GetBytes($bytes)
$WEBHOOK_SECRET = ([BitConverter]::ToString($bytes)).Replace('-', '').ToLower()
$WEBHOOK_SECRET
```

مقدار چاپ‌شده را در `npx wrangler secret put WEBHOOK_SECRET` قرار دهید و در جای امن نگه دارید؛ در مرحلهٔ ثبت webhook نیز دقیقاً همین مقدار لازم است. آن را در GitHub یا فایل قابل‌انتشار قرار ندهید.

متغیرهای غیرحساس از قبل در `wrangler.toml` هستند:

```text
BOT_USERNAME = NashnasiChatBot
BOT_TITLE = چت ناشناس
TIME_ZONE = Asia/Tehran
RATE_LIMIT_PER_MINUTE = 25
```

### 5. بررسی و Deploy

```powershell
npm run check
npm run deploy
```

این مرحله باید با Wrangler انجام شود تا import مربوط به grammY بسته‌بندی شود. نیازی به D1 binding دستی در Dashboard نیست؛ Wrangler آن را از `wrangler.toml` می‌خواند.

### 6. ثبت Telegram Webhook

پس از Deploy، آدرس Worker را از خروجی Wrangler بررسی کنید. برای Worker فعلی شما معمولاً این است:

```text
https://anonymous-chat-bot.game-developer-mb.workers.dev
```

در PowerShell:

دستور ثبت webhook با اسکریپت آماده:

```powershell
.\scripts\register-webhook.ps1 -WorkerUrl "https://anonymous-chat-bot.game-developer-mb.workers.dev" -DropPending
```

اسکریپت `WEBHOOK_SECRET` را به‌صورت ورودی مخفی از شما می‌گیرد و آن را در Header `Authorization: Bearer ...` می‌فرستد؛ مقدار Secret در URL قرار نمی‌گیرد.

**توجه:** `-DropPending` یک‌بار صف قدیمی Updateهای منتظر Telegram را خالی می‌کند. این کار می‌تواند پیام‌های تحویل‌نشدهٔ منتظر را از بین ببرد؛ چون در حال انتقال به دیتابیس تازه هستید، برای قطع تأخیرهای انباشته مفید است. اگر می‌خواهید Updateهای منتظر را حفظ کنید، دستور را بدون `-DropPending` اجرا کنید.

اسکریپت بدون فایل هم قابل اجراست:

```powershell
$secret = Read-Host "WEBHOOK_SECRET همان مقداری که در Wrangler Secret ثبت کردید"
Invoke-RestMethod -Method Post `
  -Uri "https://anonymous-chat-bot.game-developer-mb.workers.dev/register?drop_pending=0" `
  -Headers @{ Authorization = "Bearer $secret" }
```

ثبت webhook با `POST` انجام می‌شود؛ بازکردن `/register` در مرورگر با `GET` روش ثبت نیست.

### 7. تست سلامت

این آدرس را باز کنید:

```text
https://anonymous-chat-bot.game-developer-mb.workers.dev/health
```

پاسخ موفق باید JSON با `"ok": true` و `"database": "connected"` نشان دهد. شمارنده‌های صف در لحظه ممکن است صفر نباشند؛ Worker آن‌ها را در پس‌زمینه و با Cron Trigger پردازش می‌کند.

برای دیدن خطاهای Runtime، در Cloudflare Dashboard به Worker → **Observability / Logs** بروید. در خود ربات نیز مدیر می‌تواند `/errors` را اجرا کند.

## تست سناریوها

### گفتگوی ناشناس دوطرفه

1. اکانت A ربات را باز کند و `/start` و سپس `/link` را بزند.
2. اکانت B لینک A را باز کند و یک متن بفرستد.
3. A باید پیام همراه با شناسه‌ای مانند `#M123` و دکمهٔ «پاسخ به این گفتگو» دریافت کند.
4. A روی پاسخ بزند و پیام بفرستد. این پیام فقط باید به همان B برسد، نه به تمام افراد قبلی.
5. B روی دکمهٔ پاسخ همان گفتگو بزند و پاسخ بدهد.

### فهرست‌ها و پروفایل‌ها

- `/inbox` برای پیام‌های دریافتی و ID فنی `#M...`.
- `/history` برای پیام‌های ارسال و دریافت‌شده.
- `/me` برای پروفایل کاربر خودش.
- از طرف ادمین: `/admin`، `/users 1`، `/user 123456789`، `/history_admin 123456789 1`، `/recent 1`، `/stats`، `/search @username`، `/audit 1` و `/errors`.

فهرست عادی شناسهٔ پیام و کد گفتگو را نمایش می‌دهد، نه Telegram ID طرف مقابل؛ این بخش برای حفظ ناشناسی است. گزارش ادمین ID فرستنده و گیرنده را نمایش می‌دهد.

### پاک‌سازی و بلاک

- `/clearhistory` تاریخچه را فقط از نمای خود کاربر پنهان می‌کند؛ پیام‌های طرف مقابل حذف نمی‌شود.
- از دکمهٔ «حذف دوطرفه» کنار پیام یا `/deleteboth MESSAGE_ID` استفاده کنید و سپس تأیید بزنید. محتوای پیام از D1 حذف می‌شود و Worker تلاش می‌کند نسخه‌های پیام را نیز از چت‌های Telegram پاک کند.
- حذف واقعی از Telegram ممکن است برای پیام‌های قدیمی/غیرقابل‌حذف ناموفق شود؛ در این وضعیت حذف منطقی از D1 انجام می‌شود و علت تلاش ناموفق در Audit ثبت می‌شود.
- برای بلاک یک گفتگو، دکمهٔ «مسدودکردن گفتگو» را بزنید. `/blocklist` و `/unblockchat CONVERSATION_ID` آن را مدیریت می‌کنند.
- اگر کاربر Bot را Block کند، رویداد `my_chat_member` یا خطای 403 هنگام ارسال ثبت می‌شود. پیام‌های تحویل‌نشده به‌طور نامحدود Retry نمی‌شوند. پس از Unblock، کاربر باید دوباره `/start` بزند.

### دستورات مدیریتی بیشتر

```text
/admin
/users [PAGE]
/user USER_ID
/history_admin USER_ID [PAGE]
/recent [PAGE]
/stats
/search QUERY
/audit [PAGE]
/errors
/blocked [PAGE]
/send USER_ID TEXT
/broadcast TEXT
/block USER_ID
/unblock USER_ID
/retry_failed [LIMIT]
/addadmin USER_ID       # فقط Owner
/deladmin USER_ID       # فقط Owner
/maintenance on|off     # فقط Owner
```

Broadcast به صورت job ذخیره می‌شود و در پس‌زمینه پیش می‌رود؛ یک `/broadcast` بزرگ نباید زمان پاسخ webhook را چند دقیقه اشغال کند.

## چرا گاهی ارسال ممکن است همچنان شکست بخورد؟

ربات نمی‌تواند به حسابی که هرگز `/start` نکرده پیام آغازگر بفرستد. همچنین اگر کاربر Bot را بلاک کرده، حساب Telegram حذف شده یا Telegram API پیام/رسانه‌ای را برای `copyMessage` نپذیرد، تحویل ناموفق گزارش می‌شود. این موارد در `message_deliveries`، `/errors` و Audit log قابل پیگیری‌اند.

## منابع فنی

- grammY web bundle و بستهٔ npm: https://www.npmjs.com/package/grammy
- Cloudflare Wrangler configuration: https://developers.cloudflare.com/workers/wrangler/configuration/
- Cloudflare D1 migrations: https://developers.cloudflare.com/d1/reference/migrations/
- Telegram Bot API و `deleteMessage`، `copyMessage` و webhook secret: https://core.telegram.org/bots/api
